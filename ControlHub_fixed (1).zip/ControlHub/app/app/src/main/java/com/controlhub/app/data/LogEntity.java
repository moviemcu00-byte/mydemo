package com.controlhub.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Feature #3 — Local database
 * Ek row = ek log entry (Stage 8 ka Audit Log isko use karega)
 */
@Entity(tableName = "logs")
public class LogEntity {

    @PrimaryKey(autoGenerate = true)
    public long id;

    public String message;
    public String level;   // "info", "warning", "error"
    public long timestamp;

    public LogEntity(String message, String level, long timestamp) {
        this.message = message;
        this.level = level;
        this.timestamp = timestamp;
    }
}
