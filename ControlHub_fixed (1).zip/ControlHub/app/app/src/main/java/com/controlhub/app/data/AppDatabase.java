package com.controlhub.app.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.controlhub.app.apkhost.HostedApkDao;
import com.controlhub.app.apkhost.HostedApkEntity;

/**
 * Feature #3 — Local database
 * Single Room database for the whole app: apps, tasks, logs, settings, hosted_apks.
 * Baad ke stages (App Control, Automation Engine, Audit Log, Settings screen,
 * APK Host) isi ek database ko use karenge — alag-alag DB banane ki zaroorat nahi.
 *
 * NOTE — version 5 (Step 8): tasks.redactWhenDone / restoreApp / startPackage add hue.
 * NOTE — version 4 (Step 4): tasks.mode (background/foreground) add hua.
 * NOTE — version 3 (Step 2): tasks table mein taskUuid/priority/deadline/checkpoint columns aaye.
 * NOTE — version 2 (Stage 9): hosted_apks table add hui. App abhi dev/testing
 * stage mein hai (koi published/real-user data nahi), isliye proper migration
 * likhne ke bajaye fallbackToDestructiveMigration() use kiya hai — schema
 * change hone par purana local test-data clear ho jayega, jo abhi acceptable hai.
 * Real release ke paas jaate waqt isko asli Migration classes se replace karna hoga.
 */
@Database(
        entities = {AppEntity.class, TaskEntity.class, LogEntity.class, SettingEntity.class,
                HostedApkEntity.class},
        version = 5,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract AppDao appDao();
    public abstract TaskDao taskDao();
    public abstract LogDao logDao();
    public abstract SettingDao settingDao();
    public abstract HostedApkDao hostedApkDao();

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "control_hub.db"
                    )
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
