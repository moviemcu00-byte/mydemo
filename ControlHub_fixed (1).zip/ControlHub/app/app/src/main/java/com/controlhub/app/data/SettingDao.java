package com.controlhub.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface SettingDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void set(SettingEntity setting);

    @Query("SELECT * FROM settings WHERE `key` = :key LIMIT 1")
    SettingEntity get(String key);

    @Query("SELECT * FROM settings")
    List<SettingEntity> getAll();
}
