package com.controlhub.app.adapters;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Step 4 — Available app adapters. */
public class AdapterRegistry {

    private static final Map<String, AppAdapter> ADAPTERS = new LinkedHashMap<>();

    static {
        register(new WhatsAppAdapter("whatsapp", "com.whatsapp"));
        register(new WhatsAppAdapter("whatsapp_business", "com.whatsapp.w4b"));
        // Step 8 — baaki messaging apps (sab "starter": real phone par verify nahi hue)
        register(MessagingAdapter.telegram());
        register(MessagingAdapter.instagram());
        register(MessagingAdapter.messenger());
        register(MessagingAdapter.signal());
    }

    private static void register(AppAdapter a) {
        ADAPTERS.put(a.name(), a);
    }

    public static AppAdapter get(String name) {
        return ADAPTERS.get(name);
    }

    public static List<AppAdapter> all() {
        return new ArrayList<>(ADAPTERS.values());
    }
}
