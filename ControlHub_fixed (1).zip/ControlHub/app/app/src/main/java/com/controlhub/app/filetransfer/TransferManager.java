package com.controlhub.app.filetransfer;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.BitSet;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Feature #60 — /file/send  (phone -> Claude/backend)
 * Feature #61 — /file/receive (Claude/backend -> phone)
 * Feature #62 — Hold/Pause   Feature #63 — Resume   Feature #64 — Status/progress
 *
 * Design note: ye class PURE JAVA hai (android.* nahi) — normal JVM par test ho sakti hai.
 *
 * Step 5 additions:
 *  - FilePolicy: size limit (413) + khatarnaak extensions (415); storage/concurrency guards (507/429)
 *  - SHA-256: send par poori file ka sha256 status mein; receive par optional expected sha256 —
 *    sab chunks aane ke baad file ka sha256 match na ho to file DISCARD (state FAILED, HTTP 422)
 *  - Optional per-chunk sha256 (corrupt chunk dobara bhejne layak)
 *  - Atomic finalize: temp (.part) -> received_files/ rename, global lock ke saath (same naam race nahi)
 *  - Restart-resume: incoming transfer ka chhota .meta file disk par (received chunks ke saath);
 *    app restart ke baad same transferId se baaki chunks bheje ja sakte hain. 24 ghante purane adhure
 *    transfers saaf. (Send side stateless hai — restart ke baad bas startSend dobara karo.)
 */
public class TransferManager {

    public enum State { PENDING, ACTIVE, PAUSED, COMPLETED, CANCELLED, FAILED }

    private static final int MAX_ACTIVE_RECEIVES = 8;
    private static final long STALE_MS = 24L * 60 * 60 * 1000;
    private static final long FREE_SPACE_MARGIN = 50L * 1024 * 1024;

    private final File baseDir;
    private final int chunkSize;
    private final FilePolicy policy;
    private final Object finalizeLock = new Object();
    private final Map<String, SendTransfer> sends = new ConcurrentHashMap<>();
    private final Map<String, ReceiveTransfer> receives = new ConcurrentHashMap<>();

    public TransferManager(File baseDir, int chunkSize) {
        this(baseDir, chunkSize, FilePolicy.defaults());
    }

    public TransferManager(File baseDir, int chunkSize, FilePolicy policy) {
        if (chunkSize <= 0) throw new IllegalArgumentException("chunkSize must be > 0");
        this.baseDir = baseDir;
        this.chunkSize = chunkSize;
        this.policy = policy;
        restoreIncomplete();
    }

    // ============================== SEND ==============================

    private static final class SendTransfer {
        final String id;
        final File file;
        final long totalBytes;
        final int totalChunks;
        final String sha256;
        final BitSet chunksSent;
        volatile State state;

        SendTransfer(String id, File file, long totalBytes, int totalChunks, String sha256) {
            this.id = id;
            this.file = file;
            this.totalBytes = totalBytes;
            this.totalChunks = totalChunks;
            this.sha256 = sha256;
            this.chunksSent = new BitSet(Math.max(1, totalChunks));
            this.state = totalChunks == 0 ? State.COMPLETED : State.PENDING;
        }
    }

    /** Feature #60 — existing file (outbox) ke liye send-transfer; poori file ka SHA-256 nikalta hai */
    public synchronized JSONObject startSend(File source) throws IOException, JSONException {
        if (!source.isFile()) {
            throw new FileNotFoundException("Not a file: " + source);
        }
        long total = source.length();
        policy.checkSize(total);
        String sha = sha256Of(source);
        int totalChunks = (int) ((total + chunkSize - 1) / chunkSize); // ceil, 0-byte file -> 0 chunks
        String id = UUID.randomUUID().toString();
        SendTransfer t = new SendTransfer(id, source, total, totalChunks, sha);
        sends.put(id, t);
        return describeSend(t);
    }

    /** Feature #60 — ek chunk padhta hai. Index se seedha seek karta hai (order matter nahi karta). */
    public byte[] readChunk(String id, int index) throws IOException {
        SendTransfer t = getSend(id);
        synchronized (t) {
            requireReadableState(t.state);
            if (index < 0 || index >= t.totalChunks) {
                throw new IndexOutOfBoundsException("chunk index " + index + " out of range (0..." + (t.totalChunks - 1) + ")");
            }
            long offset = (long) index * chunkSize;
            int len = (int) Math.min(chunkSize, t.totalBytes - offset);
            byte[] buf = new byte[len];
            try (RandomAccessFile raf = new RandomAccessFile(t.file, "r")) {
                raf.seek(offset);
                raf.readFully(buf);
            }
            t.chunksSent.set(index);
            t.state = (t.chunksSent.cardinality() == t.totalChunks) ? State.COMPLETED : State.ACTIVE;
            return buf;
        }
    }

    public synchronized void pauseSend(String id) {
        SendTransfer t = getSend(id);
        requirePausable(t.state);
        t.state = State.PAUSED;
    }

    public synchronized void resumeSend(String id) {
        SendTransfer t = getSend(id);
        requireResumable(t.state);
        t.state = State.ACTIVE;
    }

    public synchronized void cancelSend(String id) {
        SendTransfer t = getSend(id);
        t.state = State.CANCELLED;
    }

    public JSONObject statusSend(String id) throws JSONException {
        return describeSend(getSend(id));
    }

    private JSONObject describeSend(SendTransfer t) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("transferId", t.id);
        o.put("direction", "send");
        o.put("fileName", t.file.getName());
        o.put("mimeType", FilePolicy.mimeFor(t.file.getName()));
        o.put("totalBytes", t.totalBytes);
        o.put("sha256", t.sha256);
        o.put("chunkSize", chunkSize);
        o.put("totalChunks", t.totalChunks);
        o.put("chunksSent", t.chunksSent.cardinality());
        o.put("state", t.state.name());
        o.put("percent", percent(t.chunksSent.cardinality(), t.totalChunks));
        return o;
    }

    private SendTransfer getSend(String id) {
        SendTransfer t = sends.get(id);
        if (t == null) throw new NoSuchTransferException(id);
        return t;
    }

    // ============================== RECEIVE ==============================

    private static final class ReceiveTransfer {
        final String id;
        final String fileName;
        final long totalBytes;
        final int totalChunks;
        final File tempFile;
        final File metaFile;
        final String expectedSha256; // null = caller ne nahi diya
        final long createdAt;
        final BitSet chunksReceived;
        volatile State state;
        volatile File finalFile;     // sirf COMPLETED hone ke baad
        volatile String sha256;      // poori file ka asli SHA-256 (sab chunks aane ke baad)
        volatile boolean verified;   // expected sha256 match hua
        volatile String error;

        ReceiveTransfer(String id, String fileName, long totalBytes, int totalChunks, File tempFile,
                        File metaFile, String expectedSha256, long createdAt) {
            this.id = id;
            this.fileName = fileName;
            this.totalBytes = totalBytes;
            this.totalChunks = totalChunks;
            this.tempFile = tempFile;
            this.metaFile = metaFile;
            this.expectedSha256 = expectedSha256;
            this.createdAt = createdAt;
            this.chunksReceived = new BitSet(Math.max(1, totalChunks));
            this.state = State.PENDING;
        }
    }

    public synchronized JSONObject startReceive(String rawFileName, long totalBytes) throws IOException, JSONException {
        return startReceive(rawFileName, totalBytes, null);
    }

    /** Feature #61 — naya incoming file register (expectedSha256 optional par sifarish ki jaati hai) */
    public synchronized JSONObject startReceive(String rawFileName, long totalBytes, String expectedSha256)
            throws IOException, JSONException {
        if (totalBytes < 0) {
            throw new IllegalArgumentException("totalBytes cannot be negative");
        }
        String safeName = sanitizeFileName(rawFileName);
        policy.check(safeName, totalBytes);

        String expected = null;
        if (expectedSha256 != null && !expectedSha256.trim().isEmpty()) {
            expected = expectedSha256.trim().toLowerCase();
            if (!expected.matches("[0-9a-f]{64}")) {
                throw new IllegalArgumentException("sha256 must be 64 hex characters");
            }
        }

        int active = 0;
        for (ReceiveTransfer r : receives.values()) {
            if (r.state == State.PENDING || r.state == State.ACTIVE || r.state == State.PAUSED) active++;
        }
        if (active >= MAX_ACTIVE_RECEIVES) {
            throw new FilePolicy.Rejected(429, "Too many active incoming transfers (max " + MAX_ACTIVE_RECEIVES + ")");
        }

        File tmpDir = new File(baseDir, "incoming_tmp");
        if (!tmpDir.exists() && !tmpDir.mkdirs()) {
            throw new IOException("Could not create temp directory: " + tmpDir);
        }
        long usable = tmpDir.getUsableSpace();
        if (usable > 0 && usable < totalBytes + FREE_SPACE_MARGIN) {
            throw new FilePolicy.Rejected(507, "Not enough free storage on the phone for this file");
        }

        int totalChunks = (int) ((totalBytes + chunkSize - 1) / chunkSize);
        String id = UUID.randomUUID().toString();
        File tempFile = new File(tmpDir, id + ".part");
        File metaFile = new File(tmpDir, id + ".meta");
        try (RandomAccessFile raf = new RandomAccessFile(tempFile, "rw")) {
            raf.setLength(totalBytes); // pre-allocate — random-offset writes ke liye
        }

        ReceiveTransfer t = new ReceiveTransfer(id, safeName, totalBytes, totalChunks, tempFile, metaFile,
                expected, System.currentTimeMillis());
        receives.put(id, t);
        if (totalChunks == 0) {
            finalizeReceive(t); // 0-byte file — turant complete (checksum mismatch par throw)
        } else {
            persistMeta(t);
        }
        return describeReceive(t);
    }

    public void writeChunk(String id, int index, byte[] data) throws IOException {
        writeChunk(id, index, data, null);
    }

    /** Feature #61 — ek chunk likhta hai; chunkSha256 diya ho to pehle verify. Sab aa jaayein to finalize. */
    public void writeChunk(String id, int index, byte[] data, String chunkSha256) throws IOException {
        ReceiveTransfer t = getReceive(id);
        synchronized (t) {
            requireReadableState(t.state);
            if (index < 0 || index >= t.totalChunks) {
                throw new IndexOutOfBoundsException("chunk index " + index + " out of range (0..." + (t.totalChunks - 1) + ")");
            }
            long offset = (long) index * chunkSize;
            int expected = (int) Math.min(chunkSize, t.totalBytes - offset);
            if (data.length != expected) {
                throw new IllegalArgumentException("chunk " + index + " expected " + expected + " bytes, got " + data.length);
            }
            if (chunkSha256 != null && !chunkSha256.trim().isEmpty()
                    && !sha256Hex(data).equalsIgnoreCase(chunkSha256.trim())) {
                throw new IllegalArgumentException("chunk " + index + " checksum mismatch — resend this chunk");
            }
            try (RandomAccessFile raf = new RandomAccessFile(t.tempFile, "rw")) {
                raf.seek(offset);
                raf.write(data);
            }
            t.chunksReceived.set(index);
            if (t.chunksReceived.cardinality() == t.totalChunks) {
                finalizeReceive(t);
            } else {
                t.state = State.ACTIVE;
                persistMeta(t);
            }
        }
    }

    private void finalizeReceive(ReceiveTransfer t) throws IOException {
        String actual = sha256Of(t.tempFile);
        t.sha256 = actual;

        if (t.expectedSha256 != null && !t.expectedSha256.equals(actual)) {
            t.state = State.FAILED;
            t.error = "SHA-256 mismatch — file discarded";
            //noinspection ResultOfMethodCallIgnored
            t.tempFile.delete();
            //noinspection ResultOfMethodCallIgnored
            t.metaFile.delete();
            throw new FilePolicy.Rejected(422, "SHA-256 mismatch — received file does not match the expected checksum (discarded)");
        }

        synchronized (finalizeLock) { // same naam ke do transfers ek saath finalize hon to overwrite nahi
            File finalDir = new File(baseDir, "received_files");
            if (!finalDir.exists() && !finalDir.mkdirs()) {
                throw new IOException("Could not create destination directory: " + finalDir);
            }
            File dest = uniqueDestination(finalDir, t.fileName);
            if (t.tempFile.exists() && !t.tempFile.renameTo(dest)) {
                throw new IOException("Could not finalize file to " + dest);
            }
            t.finalFile = dest;
        }
        t.verified = t.expectedSha256 != null;
        t.state = State.COMPLETED;
        //noinspection ResultOfMethodCallIgnored
        t.metaFile.delete();
    }

    public synchronized void pauseReceive(String id) {
        ReceiveTransfer t = getReceive(id);
        requirePausable(t.state);
        t.state = State.PAUSED;
        persistMetaQuietly(t);
    }

    public synchronized void resumeReceive(String id) {
        ReceiveTransfer t = getReceive(id);
        requireResumable(t.state);
        t.state = State.ACTIVE;
    }

    public synchronized void cancelReceive(String id) {
        ReceiveTransfer t = getReceive(id);
        if (t.state == State.COMPLETED || t.state == State.FAILED) return; // pehle hi terminal
        t.state = State.CANCELLED;
        //noinspection ResultOfMethodCallIgnored
        t.tempFile.delete(); // adhura/cancelled data disk par nahi chhodte
        //noinspection ResultOfMethodCallIgnored
        t.metaFile.delete();
    }

    public JSONObject statusReceive(String id) throws JSONException {
        return describeReceive(getReceive(id));
    }

    private JSONObject describeReceive(ReceiveTransfer t) throws JSONException {
        JSONObject o = new JSONObject();
        int got = t.chunksReceived.cardinality();
        o.put("transferId", t.id);
        o.put("direction", "receive");
        o.put("fileName", t.fileName);
        o.put("mimeType", FilePolicy.mimeFor(t.fileName));
        o.put("totalBytes", t.totalBytes);
        o.put("chunkSize", chunkSize);
        o.put("totalChunks", t.totalChunks);
        o.put("chunksReceived", got);
        o.put("missingCount", Math.max(0, t.totalChunks - got));
        o.put("nextMissingIndex", t.totalChunks == 0 ? -1 : t.chunksReceived.nextClearBit(0) < t.totalChunks
                ? t.chunksReceived.nextClearBit(0) : -1);
        o.put("state", t.state.name());
        o.put("percent", percent(got, t.totalChunks));
        o.put("checksumExpected", t.expectedSha256 != null);
        if (t.sha256 != null) o.put("sha256", t.sha256);
        o.put("verified", t.verified);
        if (t.error != null) o.put("error", t.error);
        if (t.finalFile != null) {
            o.put("savedAs", t.finalFile.getName());
        }
        return o;
    }

    private ReceiveTransfer getReceive(String id) {
        ReceiveTransfer t = receives.get(id);
        if (t == null) throw new NoSuchTransferException(id);
        return t;
    }

    // ============================== restart-resume (meta files) ==============================

    private void persistMetaQuietly(ReceiveTransfer t) {
        try {
            persistMeta(t);
        } catch (IOException ignored) {
        }
    }

    /** Atomic: pehle .tmp mein likho, phir rename */
    private void persistMeta(ReceiveTransfer t) throws IOException {
        Properties p = new Properties();
        p.setProperty("id", t.id);
        p.setProperty("fileName", t.fileName);
        p.setProperty("totalBytes", String.valueOf(t.totalBytes));
        p.setProperty("totalChunks", String.valueOf(t.totalChunks));
        p.setProperty("chunkSize", String.valueOf(chunkSize));
        p.setProperty("expectedSha256", t.expectedSha256 == null ? "" : t.expectedSha256);
        p.setProperty("createdAt", String.valueOf(t.createdAt));
        p.setProperty("received", toHex(t.chunksReceived.toByteArray()));
        File tmp = new File(t.metaFile.getPath() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            p.store(out, "control-hub incoming transfer");
        }
        if (!tmp.renameTo(t.metaFile)) {
            // kuch filesystems par rename existing file par fail hota hai — pehle hata ke dobara
            //noinspection ResultOfMethodCallIgnored
            t.metaFile.delete();
            if (!tmp.renameTo(t.metaFile)) {
                throw new IOException("Could not write transfer metadata");
            }
        }
    }

    private void restoreIncomplete() {
        File tmpDir = new File(baseDir, "incoming_tmp");
        File[] files = tmpDir.listFiles();
        if (files == null) return;
        long now = System.currentTimeMillis();

        for (File f : files) {
            String name = f.getName();
            if (name.endsWith(".meta.tmp")) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
                continue;
            }
            if (name.endsWith(".part")) {
                File meta = new File(tmpDir, name.substring(0, name.length() - ".part".length()) + ".meta");
                if (!meta.exists() && now - f.lastModified() > STALE_MS) {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete(); // orphan
                }
                continue;
            }
            if (!name.endsWith(".meta")) continue;

            File part = new File(tmpDir, name.substring(0, name.length() - ".meta".length()) + ".part");
            try {
                if (now - f.lastModified() > STALE_MS || !part.exists()) {
                    throw new IOException("stale or orphan");
                }
                Properties p = new Properties();
                try (InputStream in = new FileInputStream(f)) {
                    p.load(in);
                }
                String id = p.getProperty("id");
                long totalBytes = Long.parseLong(p.getProperty("totalBytes"));
                int totalChunks = Integer.parseInt(p.getProperty("totalChunks"));
                if (Integer.parseInt(p.getProperty("chunkSize")) != chunkSize
                        || part.length() != totalBytes || id == null) {
                    throw new IOException("incompatible");
                }
                String exp = p.getProperty("expectedSha256", "");
                ReceiveTransfer t = new ReceiveTransfer(id, p.getProperty("fileName"), totalBytes, totalChunks,
                        part, f, exp.isEmpty() ? null : exp, Long.parseLong(p.getProperty("createdAt", "0")));
                t.chunksReceived.or(BitSet.valueOf(fromHex(p.getProperty("received", ""))));
                int got = t.chunksReceived.cardinality();
                t.state = got > 0 ? State.ACTIVE : State.PENDING;
                receives.put(id, t);
                if (totalChunks > 0 && got == totalChunks) {
                    try {
                        finalizeReceive(t); // crash finalize se theek pehle hua tha
                    } catch (Exception e) {
                        t.state = State.FAILED;
                        t.error = String.valueOf(e.getMessage());
                    }
                }
            } catch (Exception e) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
                //noinspection ResultOfMethodCallIgnored
                part.delete();
            }
        }
    }

    // ============================== shared helpers ==============================

    private static void requireReadableState(State s) {
        if (s == State.PAUSED) throw new IllegalStateException("Transfer is paused");
        if (s == State.CANCELLED) throw new IllegalStateException("Transfer was cancelled");
        if (s == State.COMPLETED) throw new IllegalStateException("Transfer is already complete");
        if (s == State.FAILED) throw new IllegalStateException("Transfer failed");
    }

    private static void requirePausable(State s) {
        if (s == State.COMPLETED) throw new IllegalStateException("Cannot pause a completed transfer");
        if (s == State.CANCELLED) throw new IllegalStateException("Cannot pause a cancelled transfer");
        if (s == State.FAILED) throw new IllegalStateException("Cannot pause a failed transfer");
    }

    private static void requireResumable(State s) {
        if (s != State.PAUSED) throw new IllegalStateException("Transfer is not paused");
    }

    private static int percent(int done, int total) {
        return total == 0 ? 100 : (int) Math.round(100.0 * done / total);
    }

    public static String sha256Hex(byte[] data) {
        try {
            return toHex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    static String sha256Of(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                md.update(buf, 0, n);
            }
            return toHex(md.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(Character.forDigit((b >> 4) & 0xF, 16)).append(Character.forDigit(b & 0xF, 16));
        }
        return sb.toString();
    }

    private static byte[] fromHex(String hex) {
        int len = hex.length() / 2;
        byte[] out = new byte[len];
        for (int i = 0; i < len; i++) {
            out[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
        }
        return out;
    }

    /**
     * Feature #61 suraksha — path traversal se bachne ke liye. "../../etc/passwd" jaisa
     * naam sirf apna basename ("passwd") banke rehta hai; khaali/reserved naam reject.
     */
    static String sanitizeFileName(String raw) {
        if (raw == null) throw new IllegalArgumentException("fileName is required");
        String name = new File(raw.trim().replace('\\', '/')).getName(); // sirf last path segment (Windows-style \ bhi)
        if (name.isEmpty() || name.equals(".") || name.equals("..")) {
            throw new IllegalArgumentException("Invalid fileName");
        }
        if (name.indexOf('\u0000') >= 0) {
            throw new IllegalArgumentException("Invalid fileName");
        }
        return name;
    }

    /** Same naam pehle se ho to " (1)", " (2)"... jodta hai — kisi ka data overwrite nahi karta */
    private static File uniqueDestination(File dir, String fileName) {
        File candidate = new File(dir, fileName);
        if (!candidate.exists()) return candidate;

        String base = fileName;
        String ext = "";
        int dot = fileName.lastIndexOf('.');
        if (dot > 0) {
            base = fileName.substring(0, dot);
            ext = fileName.substring(dot);
        }
        int n = 1;
        do {
            candidate = new File(dir, base + " (" + n + ")" + ext);
            n++;
        } while (candidate.exists());
        return candidate;
    }

    public static final class NoSuchTransferException extends RuntimeException {
        public NoSuchTransferException(String id) {
            super("No such transfer: " + id);
        }
    }
}
