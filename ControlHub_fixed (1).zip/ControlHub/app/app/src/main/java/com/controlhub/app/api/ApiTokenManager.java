package com.controlhub.app.api;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.UUID;

/**
 * Feature #20 — Authentication token
 * Feature #42 — Encrypted storage (plaintext SharedPreferences se upgrade)
 *
 * Har API request ke saath ye token bhejna zaroori hai (header: X-Auth-Token),
 * warna server 401 (unauthorized) de dega. Token pehli baar app open hone par
 * khud-ba-khud generate ho jaata hai.
 *
 * Ab ye token plaintext mein nahi, EncryptedSharedPreferences (AndroidX
 * Security library) mein save hota hai — file disk par encrypted rehti hai,
 * aur encryption key khud Android Keystore (hardware-backed jahan available
 * ho) mein rakhi jaati hai, app code mein kahin nahi.
 */
public class ApiTokenManager {

    private static final String TAG = "ApiTokenManager";
    private static final String PREFS_NAME = "control_hub_api_prefs_encrypted";
    private static final String KEY_TOKEN = "api_token";

    /** Step 6: scoped-token store bhi isi encrypted prefs mein */
    public static SharedPreferences securePrefs(Context context) {
        return getPrefs(context);
    }

    private static SharedPreferences getPrefs(Context context) {
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            return EncryptedSharedPreferences.create(
                    context,
                    PREFS_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (GeneralSecurityException | IOException e) {
            // Honest fallback: agar kisi wajah se encrypted store na ban paaye
            // (bahut purane/custom Android builds par possible hai), plain
            // SharedPreferences par gir jaate hain taaki app crash na ho —
            // lekin ye clearly log hota hai taaki chhupa hua na rahe.
            Log.e(TAG, "Encrypted storage unavailable, falling back to plain prefs", e);
            return context.getSharedPreferences(PREFS_NAME + "_fallback", Context.MODE_PRIVATE);
        }
    }

    public static synchronized String getOrCreateToken(Context context) {
        SharedPreferences prefs = getPrefs(context);
        String token = prefs.getString(KEY_TOKEN, null);

        if (token == null) {
            token = UUID.randomUUID().toString();
            prefs.edit().putString(KEY_TOKEN, token).apply();
        }

        return token;
    }

    public static boolean isValid(Context context, String providedToken) {
        if (providedToken == null) return false;
        String actual = getOrCreateToken(context);
        // Step 6: constant-time compare (timing se token guess na ho)
        return java.security.MessageDigest.isEqual(
                actual.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                providedToken.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    /** Feature #20 helper — settings screen ke liye token regenerate karne ka option */
    public static synchronized String regenerateToken(Context context) {
        String newToken = UUID.randomUUID().toString();
        getPrefs(context).edit().putString(KEY_TOKEN, newToken).apply();
        return newToken;
    }
}
