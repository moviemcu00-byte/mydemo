package com.controlhub.app.events;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Feature #50 — Live event stream (central hub)
 * Feature #51 — Events publish karna (app start/stop, screenshot ready, task complete, error)
 *
 * Koi bhi part of app (AutomationEngine, LocalApiServer, InstalledAppsManager)
 * EventBus.publish(...) call karke ek event bhej sakta hai — ye automatically
 * sab connected WebSocket clients tak pahunch jaata hai. Publisher ko ye jaanne
 * ki zaroorat nahi ki koi listen kar bhi raha hai ya nahi.
 */
public class EventBus {

    private static final String TAG = "EventBus";

    /** WebSocket connection ka chhota wrapper — EventBus ko sirf "send" chahiye */
    public interface EventSink {
        void send(String json);
    }

    private static final List<EventSink> sinks = new CopyOnWriteArrayList<>();

    public static void register(EventSink sink) {
        sinks.add(sink);
        Log.i(TAG, "Event client connected (total: " + sinks.size() + ")");
    }

    public static void unregister(EventSink sink) {
        sinks.remove(sink);
        Log.i(TAG, "Event client disconnected (total: " + sinks.size() + ")");
    }

    public static int connectedClients() {
        return sinks.size();
    }

    /**
     * Feature #51 — ek event sab connected clients ko bhejta hai.
     * Agar koi client connected nahi hai to bas chupchaap kuch nahi karta
     * (error nahi deta) — publisher ko fikr karne ki zaroorat nahi.
     */
    public static void publish(String type, JSONObject data) {
        if (sinks.isEmpty()) return;

        JSONObject event = new JSONObject();
        try {
            event.put("type", type);
            event.put("timestamp", System.currentTimeMillis());
            event.put("data", data != null ? data : new JSONObject());
        } catch (JSONException e) {
            Log.e(TAG, "Failed to build event JSON", e);
            return;
        }

        String json = event.toString();
        for (EventSink sink : sinks) {
            try {
                sink.send(json);
            } catch (Exception e) {
                // Ek client fail hua to baaki clients ko event milna nahi rukna chahiye
                Log.w(TAG, "Failed to send event to a client, removing it: " + e.getMessage());
                sinks.remove(sink);
            }
        }
    }

    /** Chhota helper — sirf ek key-value ke saath event bhejne ke liye */
    public static void publish(String type, String key, Object value) {
        JSONObject data = new JSONObject();
        try {
            data.put(key, value);
        } catch (JSONException ignored) {
        }
        publish(type, data);
    }
}
