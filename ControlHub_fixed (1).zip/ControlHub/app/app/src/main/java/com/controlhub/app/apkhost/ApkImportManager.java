package com.controlhub.app.apkhost;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import com.controlhub.app.data.AppDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Feature #44 — APK import and validation
 *
 * Ye class ek .apk file ko app ke private storage mein copy karti hai, phir
 * PackageManager se uska metadata parse karke validate karti hai (corrupt/
 * invalid APK ko yahin pakad leti hai — "success" tabhi bolti hai jab
 * package info sahi se nikal aaya ho).
 *
 * IMPORTANT (honest note): Import karne ka matlab "install karna" nahi hai —
 * ye sirf file ko safe jagah rakh ke uska record banata hai (Feature #45 ka
 * registry). Actual chalane ke liye (Stage 10) Android ka normal install/
 * launch flow hi lagega — koi "silent embed" nahi hota.
 */
public class ApkImportManager {

    private static final String TAG = "ApkImportManager";
    private static final String STORAGE_DIR = "hosted_apks";

    public static class ImportResult {
        public final boolean success;
        public final HostedApkEntity entity;
        public final String error;

        ImportResult(boolean success, HostedApkEntity entity, String error) {
            this.success = success;
            this.entity = entity;
            this.error = error;
        }
    }

    public static ImportResult importApk(Context context, Uri sourceUri) {
        File targetDir = new File(context.getFilesDir(), STORAGE_DIR);
        if (!targetDir.exists()) {
            targetDir.mkdirs();
        }

        File targetFile = new File(targetDir, "apk_" + System.currentTimeMillis() + ".apk");

        // Step 1 — file ko copy karo app ke private storage mein
        try (InputStream in = context.getContentResolver().openInputStream(sourceUri);
             OutputStream out = new FileOutputStream(targetFile)) {

            if (in == null) {
                return new ImportResult(false, null, "Could not open source file");
            }

            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy APK file", e);
            return new ImportResult(false, null, "File copy failed: " + e.getMessage());
        }

        // Step 2 — Feature #44 validation: PackageManager se parse karke confirm karo
        // ye ek genuine, readable APK hai (corrupt file yahin pakdi jaayegi)
        PackageManager pm = context.getPackageManager();
        PackageInfo info = pm.getPackageArchiveInfo(targetFile.getAbsolutePath(), PackageManager.GET_META_DATA);

        if (info == null) {
            targetFile.delete(); // invalid file ko store nahi rakhte
            return new ImportResult(false, null, "Invalid or corrupt APK — could not parse package info");
        }

        ApplicationInfo appInfo = info.applicationInfo;
        // getPackageArchiveInfo() se mile ApplicationInfo ka sourceDir/publicSourceDir
        // khud set nahi hota — label nikaalne ke liye manually set karna padta hai
        appInfo.sourceDir = targetFile.getAbsolutePath();
        appInfo.publicSourceDir = targetFile.getAbsolutePath();

        String label = pm.getApplicationLabel(appInfo).toString();
        int minSdk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N ? appInfo.minSdkVersion : 1;

        HostedApkEntity entity = new HostedApkEntity(
                info.packageName,
                label,
                info.versionName,
                info.versionCode,
                targetFile.getAbsolutePath(),
                minSdk,
                true,
                null,
                System.currentTimeMillis()
        );

        // Feature #45 — registry mein save karo (Room, background thread se call hona chahiye)
        long id = AppDatabase.getInstance(context).hostedApkDao().insert(entity);
        entity.id = id;

        return new ImportResult(true, entity, null);
    }
}
