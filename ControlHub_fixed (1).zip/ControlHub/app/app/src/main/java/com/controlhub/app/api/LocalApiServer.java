package com.controlhub.app.api;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.util.Log;

import com.controlhub.app.accessibility.ControlHubAccessibilityService;
import com.controlhub.app.accessibility.UiElement;
import com.controlhub.app.apps.InstalledAppsManager;
import com.controlhub.app.adapters.AdapterRegistry;
import com.controlhub.app.adapters.AppAdapter;
import com.controlhub.app.automation.AutomationReasoner;
import com.controlhub.app.automation.InstructionCompiler;
import com.controlhub.app.notifications.ControlHubNotificationListener;
import com.controlhub.app.notifications.NotificationStore;
import com.controlhub.app.automation.TaskRunner;
import com.controlhub.app.data.AppDatabase;
import com.controlhub.app.data.AppEntity;
import com.controlhub.app.data.TaskEntity;
import com.controlhub.app.events.EventBus;
import com.controlhub.app.filetransfer.FilePolicy;
import com.controlhub.app.filetransfer.FileTransferBridge;
import com.controlhub.app.filetransfer.TransferManager;
import com.controlhub.app.sdk.Capability;
import com.controlhub.app.sdk.CapabilityRegistry;
import com.controlhub.app.security.ApiScope;
import com.controlhub.app.service.DeviceState;
import com.controlhub.app.security.EmergencyStopManager;
import com.controlhub.app.security.IdempotencyStore;
import com.controlhub.app.security.RateLimiter;
import com.controlhub.app.security.ScopedTokenRegistry;
import com.controlhub.app.security.TokenAuth;
import com.controlhub.app.security.AuditLogger;
import com.controlhub.app.security.ScopeManager;
import com.controlhub.app.vision.SceneBuilder;
import com.controlhub.app.service.TaskQueueManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;
import android.util.Base64;

import fi.iki.elonen.NanoHTTPD;

/**
 * Feature #19 — Local API Server
 * Feature #21 — /apps
 * Feature #22 — /app/launch, /app/stop, /app/status
 * Feature #23 — /ui/read
 * Feature #24 — /ui/click, /ui/type, /ui/scroll
 * Feature #25 — /screenshot
 * Feature #26 — /health
 * Feature #39 — Scope check (per-endpoint READ/WRITE/HIGH_RISK)
 * Feature #40 — HIGH_RISK endpoints ke liye explicit {"confirm": true}
 * Feature #41 — Audit log (har request)
 *
 * NOTE (honest limitation): abhi ye server sirf tab tak chalta hai jab tak
 * app process zinda hai. Stage 5 (Background Operation) mein isko ek
 * Foreground Service ke andar wrap karenge taaki app background mein
 * ja ke bhi server zinda rahe — abhi ke liye ye sirf desktop/Postman se
 * local testing (127.0.0.1 ya same-WiFi IP) ke kaam aayega.
 */
public class LocalApiServer extends NanoHTTPD {

    private static final String TAG = "LocalApiServer";
    public static final int PORT = 8080;
    private static final long MODULE_TIMEOUT_MS = 15000; // Feature #57 — SDK handler ki max der

    private final Context context;

    // Step 6
    private static final RateLimiter RATE = new RateLimiter();
    private static final IdempotencyStore IDEM = new IdempotencyStore();
    private static final ThreadLocal<IdemCtx> IDEM_CTX = new ThreadLocal<>();
    private static final ThreadLocal<TokenAuth.Principal> CURRENT_PRINCIPAL = new ThreadLocal<>();

    // Step 7: file transfer owner (kis token ne shuru kiya) + optional task label + progress throttle
    private static final Map<String, String> TRANSFER_OWNER = boundedMap();
    private static final Map<String, String> TRANSFER_TASK = boundedMap();
    private static final Map<String, Integer> TRANSFER_LAST_PCT = new java.util.concurrent.ConcurrentHashMap<>();

    private static Map<String, String> boundedMap() {
        return java.util.Collections.synchronizedMap(new java.util.LinkedHashMap<String, String>() {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
                return size() > 500;
            }
        });
    }

    private static final class IdemCtx {
        final String key;
        int status = 0;
        String body = "";

        IdemCtx(String key) {
            this.key = key;
        }
    }

    public LocalApiServer(Context context) {
        super(NetworkBinding.hostname(context), PORT); // Step 8: default sirf loopback
        this.context = context.getApplicationContext();
        EmergencyStopManager.init(this.context); // Step 6: Emergency Stop reboot ke baad bhi yaad rahe
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        Method method = session.getMethod();

        // Feature #26 — health check, auth ki zaroorat nahi (taaki server zinda
        // hai ya nahi ye bina token ke bhi check kiya ja sake)
        if (uri.equals("/health")) {
            return jsonResponse(Response.Status.OK, ok("status", "running"));
        }

        // Step 6: galat token bar-bar bhejne wale client (IP) ko 5 minute ke liye lock
        final String ip = session.getRemoteIpAddress() == null ? "unknown" : session.getRemoteIpAddress();
        if (!NetworkBinding.isLanAllowed(context) && !NetworkBinding.isLoopback(ip)) {
            AuditLogger.warning(context, "Rejected non-local client " + ip + " (LAN access is OFF)");
            return jsonResponse(Response.Status.FORBIDDEN, error("LAN access is disabled — enable it in Control Hub Settings"));
        }
        long lockedMs = RATE.lockedForMs(ip);
        if (lockedMs > 0) {
            return rawJson(429, error("Too many failed authentication attempts — try again in " + (lockedMs / 1000 + 1) + "s").toString(),
                    "Retry-After", String.valueOf(lockedMs / 1000 + 1));
        }

        // Feature #20 — baaki saare endpoints ke liye token check mandatory
        // Step 6: master token YA naam wala scoped token (constant-time compare)
        String token = session.getHeaders().get("x-auth-token");
        TokenAuth.Principal principal = TokenAuth.authenticate(context, token);
        if (principal == null) {
            RATE.recordFailure(ip);
            AuditLogger.warning(context, "Rejected request to " + uri + " — invalid/missing token");
            return jsonResponse(Response.Status.UNAUTHORIZED, error("Invalid or missing X-Auth-Token"));
        }
        RATE.recordSuccess(ip);

        // Feature #39 — scope check: token valid hona kaafi nahi, us scope ka
        // access bhi ON hona chahiye
        // Feature #57 — SDK modules: /x/<module>/<capability>. Scope us capability ka apna hota hai.
        CapabilityRegistry.Resolved module = null;
        ApiScope scope;
        if (uri.startsWith("/x/")) {
            module = CapabilityRegistry.resolve(uri);
            if (module == null) {
                return jsonResponse(Response.Status.NOT_FOUND, error("Unknown module capability: " + uri));
            }
            if (method != Method.POST) {
                return jsonResponse(Response.Status.METHOD_NOT_ALLOWED, error("Use POST for module capabilities"));
            }
            scope = module.capability.scope;
        } else {
            scope = ApiScope.forEndpoint(uri);
        }

        // Step 6: token management sirf master token se (aur relay allowlist mein /auth/* hai hi nahi)
        if (uri.startsWith("/auth/") && !principal.master) {
            AuditLogger.warning(context, "Rejected " + uri + " — token management needs the master token (" + principal.label() + ")");
            return jsonResponse(Response.Status.FORBIDDEN, error("Token management requires the master token"));
        }
        // Step 6: scoped token apne scope se bahar nahi ja sakta
        if (!principal.allows(scope)) {
            AuditLogger.warning(context, "Rejected request to " + uri + " — " + principal.label() + " has no " + scope + " scope");
            return jsonResponse(Response.Status.FORBIDDEN, error("This token does not have the " + scope + " scope"));
        }
        if (!ScopeManager.isEnabled(context, scope)) {
            AuditLogger.warning(context, "Rejected request to " + uri + " — scope " + scope + " is disabled");
            return jsonResponse(Response.Status.FORBIDDEN, error("Scope " + scope + " is currently disabled"));
        }

        // Step 6: rate limit. Emergency stop hamesha allowed (fail-safe). File chunks ke liye alag bada bucket.
        boolean exempt = uri.equals("/emergency/stop") || uri.equals("/emergency/status");
        if (!exempt) {
            boolean fileTraffic = uri.startsWith("/file/");
            boolean ok = RATE.tryAcquire((fileTraffic ? "f:" : "g:") + ip, fileTraffic ? 1200 : 300, 60_000)
                    && (scope != ApiScope.HIGH_RISK || RATE.tryAcquire("h:" + ip, 20, 60_000));
            if (!ok) {
                AuditLogger.warning(context, "Rate limit hit by " + ip + " on " + uri);
                return rawJson(429, error("Rate limit exceeded — slow down").toString(), "Retry-After", "30");
            }
        }

        // POST body ek hi baar padhte hain (NanoHTTPD stream sirf ek baar padha ja sakta hai),
        // aur Feature #40 (high-risk confirmation) yahin check ho jaata hai
        JSONObject body = new JSONObject();
        IdemCtx idem = null;
        if (method == Method.POST) {
            try {
                body = readJsonBody(session);
            } catch (Exception e) {
                return jsonResponse(Response.Status.BAD_REQUEST, error("Invalid JSON body"));
            }

            if (scope == ApiScope.HIGH_RISK && !body.optBoolean("confirm", false)) {
                AuditLogger.warning(context, "Blocked HIGH_RISK request to " + uri + " — missing confirm:true");
                return jsonResponse(Response.Status.PRECONDITION_FAILED,
                        error("This is a high-risk action — resend with \"confirm\": true"));
            }

            // Step 6: HIGH_RISK POST ke liye idempotency key zaroori (replay/double-execution se bachav)
            if (scope == ApiScope.HIGH_RISK) {
                String key = body.optString("idempotencyKey", "");
                body.remove("idempotencyKey");
                if (key.isEmpty()) {
                    String h = session.getHeaders().get("x-idempotency-key");
                    key = h == null ? "" : h.trim();
                }
                if (key.isEmpty()) {
                    return rawJson(428, error("High-risk requests need an idempotency key — send the X-Idempotency-Key header "
                            + "(or \"idempotencyKey\" in the body): a unique string of 8-100 chars [A-Za-z0-9_.:-]").toString(), null, null);
                }
                if (!IdempotencyStore.isValidKey(key)) {
                    return jsonResponse(Response.Status.BAD_REQUEST, error("Invalid idempotency key format (8-100 chars of A-Za-z0-9_.:-)"));
                }
                // Optional freshness check: X-Timestamp (epoch ms) 5 minute se purana/aage ka nahi
                String ts = session.getHeaders().get("x-timestamp");
                if (ts != null) {
                    try {
                        long t = Long.parseLong(ts.trim());
                        if (Math.abs(System.currentTimeMillis() - t) > 5 * 60_000) {
                            AuditLogger.warning(context, "Rejected stale/future X-Timestamp on " + uri);
                            return jsonResponse(Response.Status.BAD_REQUEST, error("X-Timestamp is more than 5 minutes off — possible replay"));
                        }
                    } catch (NumberFormatException e) {
                        return jsonResponse(Response.Status.BAD_REQUEST, error("X-Timestamp must be epoch milliseconds"));
                    }
                }
                String fullKey = principal.id + ":" + key;
                String fp = IdempotencyStore.fingerprint(method.name(), uri, body.toString());
                IdempotencyStore.Decision d = IDEM.begin(fullKey, fp);
                switch (d.kind) {
                    case REPLAY:
                        AuditLogger.info(context, "Idempotent replay on " + uri + " — cached response returned, NOT executed again");
                        return rawJson(d.status, d.body, "Idempotent-Replay", "true");
                    case CONFLICT:
                        return rawJson(422, error("This idempotency key was already used for a different request").toString(), null, null);
                    case IN_PROGRESS:
                        return jsonResponse(Response.Status.CONFLICT, error("A request with this idempotency key is still being processed"));
                    default:
                        idem = new IdemCtx(fullKey);
                }
            }
        }

        AuditLogger.info(context, "Request: " + method + " " + uri + " (scope=" + scope + ", by=" + principal.label() + ")");

        if (idem != null) IDEM_CTX.set(idem);
        CURRENT_PRINCIPAL.set(principal);
        try {
            Response response = route(session, uri, method, body, module);
            if (idem != null) IDEM.complete(idem.key, idem.status, idem.body);
            return response;
        } catch (RuntimeException e) {
            if (idem != null) IDEM.abandon(idem.key);
            throw e;
        } finally {
            IDEM_CTX.remove();
            CURRENT_PRINCIPAL.remove();
        }
    }

    /** Step 6: dispatch ab alag method mein (taaki serve() idempotency/rate-limit sambhal sake) */
    private Response route(IHTTPSession session, String uri, Method method, JSONObject body,
                           CapabilityRegistry.Resolved module) {
        // Step 7: file transfer ek token ka hai — doosra (scoped) token uski transferId nahi chhoo sakta
        if (uri.startsWith("/file/") && !uri.endsWith("/start")) {
            String tid = firstParam(session.getParameters(), "transferId");
            if (tid == null) tid = body.optString("transferId", null);
            Response denied = checkTransferOwner(tid);
            if (denied != null) return denied;
        }
        try {
            if (module != null) {
                return handleModuleCall(module, body);
            }
            if (uri.equals("/ui/long_click") && method == Method.POST) {
                return handleUiLongClick(body);
            }
            if (uri.equals("/ui/key") && method == Method.POST) {
                return handleUiKey(body);
            }
            if (uri.equals("/device/state") && method == Method.GET) {
                return handleDeviceState();
            }
            if (uri.equals("/auth/tokens/create") && method == Method.POST) {
                return handleTokenCreate(body);
            }
            if (uri.equals("/auth/tokens/list") && method == Method.GET) {
                return handleTokenList();
            }
            if (uri.equals("/auth/tokens/revoke") && method == Method.POST) {
                return handleTokenRevoke(body);
            }
            if (uri.equals("/emergency/stop") && method == Method.POST) {
                return handleEmergencyStop();
            }
            if (uri.equals("/emergency/status") && method == Method.GET) {
                return jsonResponse(Response.Status.OK, ok("stopped", com.controlhub.app.security.EmergencyStopManager.isStopped()));
            }
            if (uri.equals("/notifications") && method == Method.GET) {
                return handleNotifications(session);
            }
            if (uri.equals("/notification/reply") && method == Method.POST) {
                return handleNotificationReply(body);
            }
            if (uri.equals("/adapters") && method == Method.GET) {
                return handleAdapters();
            }
            if (uri.equals("/task/create") && method == Method.POST) {
                return handleTaskCreate(body);
            }
            if (uri.equals("/task/status") && method == Method.GET) {
                return handleTaskStatus(session);
            }
            if (uri.equals("/task/list") && method == Method.GET) {
                return handleTaskList(session);
            }
            if (uri.equals("/task/pause") && method == Method.POST) {
                return handleTaskPause(body);
            }
            if (uri.equals("/task/resume") && method == Method.POST) {
                return handleTaskResume(body);
            }
            if (uri.equals("/task/retry") && method == Method.POST) {
                return handleTaskRetry(body);
            }
            if (uri.equals("/task/delete") && method == Method.POST) {
                return handleTaskDelete(body);
            }
            if (uri.equals("/task/purge") && method == Method.POST) {
                return handleTaskPurge(body);
            }
            if (uri.equals("/task/cancel") && method == Method.POST) {
                return handleTaskCancel(body);
            }
            if (uri.equals("/apps") && method == Method.GET) {
                return handleApps();
            }
            if (uri.equals("/app/launch") && method == Method.POST) {
                return handleAppLaunch(body);
            }
            if (uri.equals("/app/stop") && method == Method.POST) {
                return handleAppStop(body);
            }
            if (uri.equals("/app/status") && method == Method.GET) {
                return handleAppStatus(session);
            }
            if (uri.equals("/ui/read") && method == Method.GET) {
                return handleUiRead();
            }
            if (uri.equals("/ui/click") && method == Method.POST) {
                return handleUiClick(body);
            }
            if (uri.equals("/ui/type") && method == Method.POST) {
                return handleUiType(body);
            }
            if (uri.equals("/ui/scroll") && method == Method.POST) {
                return handleUiScroll(body);
            }
            if (uri.equals("/screenshot") && method == Method.GET) {
                return handleScreenshot();
            }
            if (uri.equals("/capabilities") && method == Method.GET) {
                return handleCapabilities();
            }
            if (uri.equals("/scene") && method == Method.GET) {
                return handleScene();
            }
            if (uri.equals("/ui/back") && method == Method.POST) {
                return handleUiNav(true);
            }
            if (uri.equals("/ui/home") && method == Method.POST) {
                return handleUiNav(false);
            }
            if (uri.equals("/file/send/start") && method == Method.POST) {
                return handleFileSendStart(body);
            }
            if (uri.equals("/file/send/chunk") && method == Method.GET) {
                return handleFileSendChunk(session);
            }
            if (uri.equals("/file/send/status") && method == Method.GET) {
                return handleFileTransferStatus(session, true);
            }
            if (uri.equals("/file/send/pause") && method == Method.POST) {
                return handleFileTransferControl(body, true, "pause");
            }
            if (uri.equals("/file/send/resume") && method == Method.POST) {
                return handleFileTransferControl(body, true, "resume");
            }
            if (uri.equals("/file/send/cancel") && method == Method.POST) {
                return handleFileTransferControl(body, true, "cancel");
            }
            if (uri.equals("/file/receive/start") && method == Method.POST) {
                return handleFileReceiveStart(body);
            }
            if (uri.equals("/file/receive/chunk") && method == Method.POST) {
                return handleFileReceiveChunk(body);
            }
            if (uri.equals("/file/receive/status") && method == Method.GET) {
                return handleFileTransferStatus(session, false);
            }
            if (uri.equals("/file/receive/pause") && method == Method.POST) {
                return handleFileTransferControl(body, false, "pause");
            }
            if (uri.equals("/file/receive/resume") && method == Method.POST) {
                return handleFileTransferControl(body, false, "resume");
            }
            if (uri.equals("/file/receive/cancel") && method == Method.POST) {
                return handleFileTransferControl(body, false, "cancel");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error handling " + uri, e);
            AuditLogger.error(context, "Error handling " + uri + ": " + e.getMessage());
            EventBus.publish("error", "message", "Error handling " + uri + ": " + e.getMessage()); // Feature #51
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("Server error: " + e.getMessage()));
        }

        return jsonResponse(Response.Status.NOT_FOUND, error("Unknown endpoint: " + uri));
    }

    // -------------------- Feature #21 --------------------
    private Response handleApps() {
        List<AppEntity> apps = InstalledAppsManager.queryInstalledApps(context);
        JSONArray array = new JSONArray();
        try {
            for (AppEntity app : apps) {
                JSONObject obj = new JSONObject();
                obj.put("packageName", app.packageName);
                obj.put("label", app.appLabel);
                obj.put("running", app.isRunning);
                array.put(obj);
            }
        } catch (JSONException e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("JSON build failed"));
        }
        return jsonResponse(Response.Status.OK, array);
    }

    // -------------------- Feature #22 --------------------
    private Response handleAppLaunch(JSONObject body) throws Exception {
        String packageName = body.optString("package", null);
        if (packageName == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'package' field"));
        }
        // Feature #29/#30 — queue ke through, taaki dusre actions ke saath race na ho,
        // aur transient fail ho to ek baar dobara try ho
        boolean launched = TaskQueueManager.getInstance().submitAndWait(() ->
                InstalledAppsManager.launchApp(context, packageName));
        return jsonResponse(Response.Status.OK, ok("launched", launched));
    }

    // Feature #40 — HIGH_RISK: is point tak pahunchna matlab confirm:true already check ho chuka
    private Response handleAppStop(JSONObject body) throws Exception {
        String packageName = body.optString("package", null);
        if (packageName == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'package' field"));
        }
        TaskQueueManager.getInstance().submitAndWait(() -> {
            InstalledAppsManager.stopApp(context, packageName);
            return true;
        });
        AuditLogger.warning(context, "app/stop executed for " + packageName);
        return jsonResponse(Response.Status.OK, ok("requested", true));
    }

    private Response handleAppStatus(IHTTPSession session) {
        Map<String, List<String>> params = session.getParameters();
        String packageName = firstParam(params, "package");
        if (packageName == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'package' query param"));
        }
        boolean running = InstalledAppsManager.isAppRunning(context, packageName);
        return jsonResponse(Response.Status.OK, ok("running", running));
    }

    // -------------------- Feature #23 --------------------
    private Response handleUiRead() {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE,
                    error("Accessibility Service is not running — enable it first (Feature #11)"));
        }

        List<UiElement> elements = service.readUi();
        JSONArray array = new JSONArray();
        try {
            for (UiElement el : elements) {
                JSONObject obj = new JSONObject();
                obj.put("elementId", el.elementId);
                obj.put("text", el.text);
                obj.put("className", el.className);
                obj.put("resourceId", el.resourceId);
                obj.put("contentDesc", el.contentDesc);
                obj.put("package", el.packageName);
                obj.put("depth", el.depth);
                obj.put("parentId", el.parentId);
                obj.put("enabled", el.enabled);
                obj.put("clickable", el.clickable);
                obj.put("scrollable", el.scrollable);
                obj.put("editable", el.editable);
                obj.put("bounds", el.bounds.toShortString());
                array.put(obj);
            }
        } catch (JSONException e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("JSON build failed"));
        }
        return jsonResponse(Response.Status.OK, array);
    }

    // -------------------- Feature #24 --------------------
    private Response handleUiClick(JSONObject body) throws Exception {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error("Accessibility Service is not running"));
        }

        if (body.has("element_id")) {
            int elementId = body.getInt("element_id");
            boolean tapped = TaskQueueManager.getInstance().submitAndWait(() ->
                    service.tapElement(elementId));
            return jsonResponse(Response.Status.OK, ok("tapped", tapped));
        }
        if (body.has("x") && body.has("y")) {
            int x = body.getInt("x");
            int y = body.getInt("y");
            TaskQueueManager.getInstance().submitAndWait(() -> {
                service.tap(x, y);
                return true;
            });
            return jsonResponse(Response.Status.OK, ok("tapped", true));
        }
        return jsonResponse(Response.Status.BAD_REQUEST, error("Provide either 'element_id' or 'x'+'y'"));
    }

    // Feature #40 — HIGH_RISK: confirm:true already check ho chuka serve() mein
    private Response handleUiType(JSONObject body) throws Exception {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error("Accessibility Service is not running"));
        }
        String text = body.optString("text", null);
        if (text == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'text' field"));
        }
        boolean typed = TaskQueueManager.getInstance().submitAndWait(() ->
                service.typeText(text));
        AuditLogger.warning(context, "ui/type executed (" + text.length() + " chars)");
        return jsonResponse(Response.Status.OK, ok("typed", typed));
    }

    private Response handleUiScroll(JSONObject body) throws Exception {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error("Accessibility Service is not running"));
        }
        String direction = body.optString("direction", null);
        if (direction == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'direction' field"));
        }
        TaskQueueManager.getInstance().submitAndWait(() -> {
            service.scroll(direction);
            return true;
        });
        return jsonResponse(Response.Status.OK, ok("scrolled", direction));
    }

    // -------------------- Feature #25 --------------------
    private Response handleScreenshot() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return jsonResponse(Response.Status.NOT_IMPLEMENTED,
                    error("Screenshot requires Android 11 (API 30) or higher"));
        }

        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error("Accessibility Service is not running"));
        }

        Bitmap bitmap = service.takeScreenshotSync(5000);
        if (bitmap == null) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("Screenshot capture failed or timed out"));
        }

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] pngBytes = stream.toByteArray();

        EventBus.publish("screenshot.ready", "sizeBytes", pngBytes.length); // Feature #51

        return newFixedLengthResponse(Response.Status.OK, "image/png",
                new ByteArrayInputStream(pngBytes), pngBytes.length);
    }

    // -------------------- Feature #57 — SDK module call --------------------
    // Body: {"arguments": {...}, "confirm": true}   (confirm sirf HIGH_RISK capability ke liye,
    // wo check serve() mein ho chuka). Yahan tak pahunchna = token + scope + confirm sab pass.
    private Response handleModuleCall(CapabilityRegistry.Resolved module, JSONObject body) {
        final Capability capability = module.capability;
        JSONObject given = body.optJSONObject("arguments");
        final JSONObject args = given != null ? given : new JSONObject();

        String problem = capability.validate(args);
        if (problem != null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error(problem));
        }

        String label = module.module.name() + "." + capability.name;
        try {
            // submitOnce: serialized queue + timeout, RETRY NAHI (third-party side-effect do baar nahi chalna chahiye)
            JSONObject result = TaskQueueManager.getInstance().submitOnce(
                    () -> capability.handler.handle(context, args), MODULE_TIMEOUT_MS);
            if (capability.scope != ApiScope.READ) {
                AuditLogger.warning(context, "Module capability executed: " + label + " (scope=" + capability.scope + ")");
            }
            return jsonResponse(Response.Status.OK, result != null ? result : new JSONObject());
        } catch (IllegalArgumentException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error(String.valueOf(e.getMessage())));
        } catch (TimeoutException e) {
            AuditLogger.error(context, "Module capability timed out: " + label);
            EventBus.publish("error", "message", "Module capability timed out: " + label);
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error(label + " timed out"));
        } catch (Exception e) {
            String msg = String.valueOf(e.getMessage());
            if (msg.length() > 200) msg = msg.substring(0, 200);
            AuditLogger.error(context, "Module capability failed: " + label + " — " + msg);
            EventBus.publish("error", "message", "Module capability failed: " + label);
            return jsonResponse(Response.Status.INTERNAL_ERROR, error(label + " failed: " + msg));
        }
    }

    // -------------------- Stage 15: File Transfer (Feature #60-64) --------------------

    // Feature #60 — sirf outbox/ ke andar ki file bhej sakte hain (Stage 9 ka pattern:
    // pehle file ko app ke apne folder mein laao, phir usse "send" karo — poore phone
    // storage ka arbitrary path yahan jaanbujh ke allow nahi kiya)
    private Response handleFileSendStart(JSONObject body) {
        String fileName = body.optString("fileName", null);
        if (fileName == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'fileName' field"));
        }
        try {
            java.io.File file = FileTransferBridge.resolveOutboxFile(context, fileName);
            JSONObject result = FileTransferBridge.get(context).startSend(file);
            registerTransfer(result, body);
            return jsonResponse(Response.Status.OK, result);
        } catch (FilePolicy.Rejected e) {
            return rejectedResponse(e);
        } catch (IllegalArgumentException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error(String.valueOf(e.getMessage())));
        } catch (java.io.FileNotFoundException e) {
            return jsonResponse(Response.Status.NOT_FOUND,
                    error("File not found in outbox: " + fileName + " (adb/Storage Access Framework se outbox/ mein daalo)"));
        } catch (Exception e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("Could not start send: " + e.getMessage()));
        }
    }

    private Response handleFileSendChunk(IHTTPSession session) {
        Map<String, List<String>> params = session.getParameters();
        String transferId = firstParam(params, "transferId");
        String indexStr = firstParam(params, "index");
        if (transferId == null || indexStr == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'transferId' or 'index' query param"));
        }
        try {
            int index = Integer.parseInt(indexStr);
            byte[] chunk = FileTransferBridge.get(context).readChunk(transferId, index);
            JSONObject result = new JSONObject();
            result.put("transferId", transferId);
            result.put("index", index);
            result.put("dataBase64", Base64.encodeToString(chunk, Base64.NO_WRAP));
            result.put("chunkSha256", TransferManager.sha256Hex(chunk)); // Step 5: receiver chunk verify kar sake
            publishFileProgress(transferId, FileTransferBridge.get(context).statusSend(transferId)); // Step 7
            return jsonResponse(Response.Status.OK, result);
        } catch (NumberFormatException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("'index' must be a number"));
        } catch (TransferManager.NoSuchTransferException e) {
            return jsonResponse(Response.Status.NOT_FOUND, error(String.valueOf(e.getMessage())));
        } catch (IndexOutOfBoundsException | IllegalStateException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error(String.valueOf(e.getMessage())));
        } catch (Exception e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("Could not read chunk: " + e.getMessage()));
        }
    }

    // Feature #61 — Claude/backend se phone par naya file
    private Response handleFileReceiveStart(JSONObject body) {
        String fileName = body.optString("fileName", null);
        if (fileName == null || !body.has("totalBytes")) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'fileName' or 'totalBytes' field"));
        }
        try {
            long totalBytes = body.getLong("totalBytes");
            String sha256 = body.optString("sha256", null); // Step 5: poori file ka expected SHA-256 (sifarish)
            JSONObject result = FileTransferBridge.get(context).startReceive(fileName, totalBytes, sha256);
            registerTransfer(result, body);
            return jsonResponse(Response.Status.OK, result);
        } catch (FilePolicy.Rejected e) {
            return rejectedResponse(e);
        } catch (IllegalArgumentException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error(String.valueOf(e.getMessage())));
        } catch (Exception e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("Could not start receive: " + e.getMessage()));
        }
    }

    private Response handleFileReceiveChunk(JSONObject body) {
        String transferId = body.optString("transferId", null);
        if (transferId == null || !body.has("index") || !body.has("dataBase64")) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'transferId', 'index' or 'dataBase64' field"));
        }
        try {
            int index = body.getInt("index");
            byte[] data = Base64.decode(body.getString("dataBase64"), Base64.DEFAULT);
            String chunkSha256 = body.optString("chunkSha256", null); // Step 5: optional per-chunk verify
            FileTransferBridge.get(context).writeChunk(transferId, index, data, chunkSha256);
            JSONObject st = FileTransferBridge.get(context).statusReceive(transferId);
            publishFileProgress(transferId, st); // Step 7
            return jsonResponse(Response.Status.OK, st);
        } catch (FilePolicy.Rejected e) {
            return rejectedResponse(e);
        } catch (TransferManager.NoSuchTransferException e) {
            return jsonResponse(Response.Status.NOT_FOUND, error(String.valueOf(e.getMessage())));
        } catch (IndexOutOfBoundsException | IllegalStateException | IllegalArgumentException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error(String.valueOf(e.getMessage())));
        } catch (Exception e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("Could not write chunk: " + e.getMessage()));
        }
    }

    // Feature #64 — status/progress, dono direction ke liye common
    private Response handleFileTransferStatus(IHTTPSession session, boolean isSend) {
        String transferId = firstParam(session.getParameters(), "transferId");
        if (transferId == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'transferId' query param"));
        }
        try {
            JSONObject result = isSend
                    ? FileTransferBridge.get(context).statusSend(transferId)
                    : FileTransferBridge.get(context).statusReceive(transferId);
            return jsonResponse(Response.Status.OK, result);
        } catch (TransferManager.NoSuchTransferException e) {
            return jsonResponse(Response.Status.NOT_FOUND, error(String.valueOf(e.getMessage())));
        } catch (Exception e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("Status check failed: " + e.getMessage()));
        }
    }

    // Feature #62/#63 — pause/resume/cancel, dono direction ke liye common
    private Response handleFileTransferControl(JSONObject body, boolean isSend, String action) {
        String transferId = body.optString("transferId", null);
        if (transferId == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'transferId' field"));
        }
        try {
            TransferManager tm = FileTransferBridge.get(context);
            switch (action) {
                case "pause":
                    if (isSend) tm.pauseSend(transferId); else tm.pauseReceive(transferId);
                    break;
                case "resume":
                    if (isSend) tm.resumeSend(transferId); else tm.resumeReceive(transferId);
                    break;
                case "cancel":
                    if (isSend) tm.cancelSend(transferId); else tm.cancelReceive(transferId);
                    break;
            }
            return jsonResponse(Response.Status.OK, isSend ? tm.statusSend(transferId) : tm.statusReceive(transferId));
        } catch (TransferManager.NoSuchTransferException e) {
            return jsonResponse(Response.Status.NOT_FOUND, error(String.valueOf(e.getMessage())));
        } catch (IllegalStateException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error(String.valueOf(e.getMessage())));
        } catch (Exception e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error(action + " failed: " + e.getMessage()));
        }
    }

    // -------------------- Stage 13 support --------------------
    // Stage 7 ka SceneBuilder ab API se bhi milta hai: elements + semantic roles
    // (screenshot alag /screenshot endpoint se aata hai, payload chhota rakhne ke liye)
    private Response handleScene() {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error("Accessibility Service is not running"));
        }
        List<UiElement> elements = service.readUi();
        JSONObject scene = new SceneBuilder().buildScene(elements, false);
        return jsonResponse(Response.Status.OK, scene);
    }

    // Back / Home — insaan jaisa navigate karne ke liye zaroori (Feature #18 ke functions)
    private Response handleUiNav(boolean back) throws Exception {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error("Accessibility Service is not running"));
        }
        TaskQueueManager.getInstance().submitAndWait(() -> {
            if (back) {
                service.pressBack();
            } else {
                service.pressHome();
            }
            return true;
        });
        return jsonResponse(Response.Status.OK, ok(back ? "pressedBack" : "pressedHome", true));
    }

    // -------------------- Feature #52 --------------------
    // Master API / Nex Browser sabse pehle ye endpoint call karke jaan sakta hai
    // ki Control Hub kya-kya kar sakta hai, kis scope ke saath, aur events kahan
    // milenge — yahi "capability domain" registration ka Control-Hub-side hissa hai.
    private Response handleCapabilities() {
        try {
            JSONObject manifest = new JSONObject();
            manifest.put("domain", "android_control_hub");
            manifest.put("version", "0.1.0");
            manifest.put("apiPort", PORT);
            manifest.put("eventStreamPort", com.controlhub.app.events.EventWebSocketServer.PORT);
            manifest.put("auth", "X-Auth-Token header (REST) / ?token= query param (WebSocket)");

            JSONArray endpoints = new JSONArray();
            endpoints.put(cap("GET", "/health", "READ", "Server zinda hai ya nahi (auth nahi chahiye)"));
            endpoints.put(cap("GET", "/capabilities", "READ", "Ye manifest"));
            endpoints.put(cap("GET", "/apps", "READ", "Installed launchable apps ki list"));
            endpoints.put(cap("GET", "/app/status?package=", "READ", "Kya app abhi chal rahi hai"));
            endpoints.put(cap("POST", "/app/launch", "WRITE", "App kholna — body: {package}"));
            endpoints.put(cap("POST", "/app/stop", "HIGH_RISK", "App band karne ki koshish — body: {package, confirm:true}"));
            endpoints.put(cap("GET", "/ui/read", "READ", "Screen ke elements padhna"));
            endpoints.put(cap("POST", "/ui/click", "WRITE", "Tap — body: {element_id} ya {x,y}"));
            endpoints.put(cap("POST", "/ui/type", "HIGH_RISK", "Text likhna — body: {text, confirm:true}"));
            endpoints.put(cap("POST", "/ui/scroll", "WRITE", "Scroll — body: {direction}"));
            endpoints.put(cap("GET", "/screenshot", "READ", "Screenshot (PNG) — Android 11+"));
            endpoints.put(cap("GET", "/scene", "READ", "Screen elements + semantic roles (button, text_field, ...)"));
            endpoints.put(cap("POST", "/ui/back", "WRITE", "Back button dabana"));
            endpoints.put(cap("POST", "/ui/home", "WRITE", "Home button dabana"));
            endpoints.put(cap("POST", "/file/send/start", "READ", "outbox/ ki file bhejne ke liye transfer shuru — body: {fileName}"));
            endpoints.put(cap("GET", "/file/send/chunk", "READ", "Ek chunk padhna — ?transferId=&index= (response mein chunkSha256; start response mein poori file ka sha256)"));
            endpoints.put(cap("GET", "/file/send/status", "READ", "Send progress — ?transferId="));
            endpoints.put(cap("POST", "/file/send/pause", "READ", "body: {transferId}"));
            endpoints.put(cap("POST", "/file/send/resume", "READ", "body: {transferId}"));
            endpoints.put(cap("POST", "/file/send/cancel", "READ", "body: {transferId}"));
            endpoints.put(cap("POST", "/file/receive/start", "WRITE", "Naya incoming file register — body: {fileName, totalBytes, sha256?}. Limits: 100 MB, apk/exe/sh jaise types 415. Galat sha256 par file discard (422). Status mein nextMissingIndex se resume"));
            endpoints.put(cap("POST", "/file/receive/chunk", "WRITE", "body: {transferId, index, dataBase64, chunkSha256?}"));
            endpoints.put(cap("GET", "/file/receive/status", "WRITE", "Receive progress — ?transferId="));
            endpoints.put(cap("POST", "/file/receive/pause", "WRITE", "body: {transferId}"));
            endpoints.put(cap("POST", "/file/receive/resume", "WRITE", "body: {transferId}"));
            endpoints.put(cap("POST", "/file/receive/cancel", "WRITE", "body: {transferId}"));
            endpoints.put(cap("POST", "/task/create", "HIGH_RISK", "Automation task banana (extra: restoreApp?(default true — task ke baad pichli app par wapas), redactWhenDone?(task khatam hote hi message text mita do)) (HIGH_RISK POST: X-Idempotency-Key header ya body idempotencyKey zaroori) — body: {instructions, mode?(auto|background|foreground), allowForeground?, priority?(-10..10), timeoutSeconds?(default 300), confirm:true}. UI commands (open/tap/type/scroll/back/home) ke liye allowForeground:true zaroori. Commands (nayi line ya ;; se alag): open:<pkg>, tap:<selectors>, type:<text>, scroll:<dir>, back, home, wait:<sec>, reply:<pkg|*>|<contact|key>|<text>, do:<adapter>.<action>|args. Selectors: id=/desc=/text=/has=/cls=/within=/nth=/xy= (' & ' se jodo, ' || ' se alternates). Verify: ' => appears:|gone:|pkg:|text:|none'"));
            endpoints.put(cap("POST", "/ui/long_click", "WRITE", "Long-press — body: {element_id} ya {x, y}"));
            endpoints.put(cap("POST", "/ui/key", "WRITE", "Key/system action — body: {key: back|home|recents|notifications|quick_settings|enter|clear}"));
            endpoints.put(cap("GET", "/device/state", "READ", "Battery, accessibility/notification-access status, screen lock, foreground app, active task, emergency stop"));
            endpoints.put(cap("POST", "/auth/tokens/create", "HIGH_RISK", "LOCAL ONLY (master token, relay se nahi): naam wala scoped token — body: {name, scopes:[READ|WRITE|HIGH_RISK], confirm:true}. Token sirf ek baar dikhta hai"));
            endpoints.put(cap("GET", "/auth/tokens/list", "READ", "LOCAL ONLY: scoped tokens ki list (hash/plain nahi)"));
            endpoints.put(cap("POST", "/auth/tokens/revoke", "WRITE", "LOCAL ONLY: body: {id} — turant revoke"));
            endpoints.put(cap("POST", "/emergency/stop", "READ", "Fail-safe: sab automation turant band + active tasks cancel. Resume sirf phone par hota hai"));
            endpoints.put(cap("GET", "/emergency/status", "READ", "Emergency stop active hai ya nahi"));
            endpoints.put(cap("GET", "/notifications?package=&limit=", "READ", "Active notifications (metadata; title/text sirf tab jab Settings mein expose ON ho)"));
            endpoints.put(cap("POST", "/notification/reply", "HIGH_RISK", "Mode A inline reply — body: {key, text, confirm:true}"));
            endpoints.put(cap("GET", "/adapters", "READ", "App adapters (whatsapp, whatsapp_business) aur unke actions — status 'starter' = device par verify nahi hua"));
            endpoints.put(cap("GET", "/task/status?id= | ?uuid=", "READ", "Task ki poori state: status, currentStep/totalSteps, retryCount, deadlineAt, lastError"));
            endpoints.put(cap("GET", "/task/list?status=&limit=", "READ", "Recent tasks (default 20, max 100)"));
            endpoints.put(cap("POST", "/task/cancel", "WRITE", "body: {taskId | taskUuid}"));
            endpoints.put(cap("POST", "/task/delete", "WRITE", "Khatam hua task (aur uska message text) delete — body: {taskId | taskUuid}"));
            endpoints.put(cap("POST", "/task/purge", "HIGH_RISK", "Khatam tasks bulk delete — body: {olderThanDays?, status?, confirm:true}"));
            endpoints.put(cap("POST", "/task/pause", "WRITE", "body: {taskId | taskUuid} — checkpoint par ruk jata hai"));
            endpoints.put(cap("POST", "/task/resume", "WRITE", "body: {taskId | taskUuid} — paused task wahin se chalta hai"));
            endpoints.put(cap("POST", "/task/retry", "WRITE", "body: {taskId | taskUuid, fromStart?, timeoutSeconds?} — sirf failed task"));
            manifest.put("endpoints", endpoints);
            manifest.put("modules", CapabilityRegistry.describeAll()); // Feature #57

            JSONArray events = new JSONArray();
            events.put("app.started");
            events.put("app.stopped");
            events.put("screenshot.ready");
            events.put("screen.changed");
            events.put("permission.changed");
            events.put("file.progress");
            events.put("notification.posted");
            events.put("notification.removed");
            events.put("task.needs_attention");
            events.put("task.progress");
            events.put("task.complete");
            events.put("error");
            manifest.put("events", events);

            return jsonResponse(Response.Status.OK, manifest);
        } catch (JSONException e) {
            return jsonResponse(Response.Status.INTERNAL_ERROR, error("JSON build failed"));
        }
    }

    private JSONObject cap(String method, String path, String scope, String description) throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("method", method);
        obj.put("path", path);
        obj.put("scope", scope);
        obj.put("description", description);
        return obj;
    }

    // -------------------- Task endpoints (Step 1 + Step 2) --------------------
    private static final int MAX_INSTRUCTIONS_LENGTH = 4000;
    private static final long DEFAULT_TIMEOUT_SEC = 300;   // 5 min
    private static final long MAX_TIMEOUT_SEC = 3600;      // 1 ghanta

    private JSONObject taskToJson(TaskEntity t) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("taskId", t.id);
        o.put("taskUuid", t.taskUuid);
        o.put("deviceId", t.deviceId);
        o.put("status", t.status);
        o.put("priority", t.priority);
        o.put("mode", t.mode);
        o.put("restoreApp", t.restoreApp);
        o.put("redactWhenDone", t.redactWhenDone);
        o.put("instructionsRedacted", TaskEntity.REDACTED.equals(t.instructions));
        o.put("currentStep", t.currentStep);
        o.put("totalSteps", AutomationReasoner.parseCommands(t.instructions).size());
        o.put("retryCount", t.retryCount);
        o.put("recoveryCount", t.recoveryCount);
        o.put("deadlineAt", t.deadlineAt);
        o.put("createdAt", t.createdAt);
        o.put("updatedAt", t.updatedAt);
        o.put("lastError", t.lastError == null ? JSONObject.NULL : t.lastError);
        return o;
    }

    /** ?id=<number> ya ?uuid=<taskUuid> — dono chalte hain (GET); body mein taskId/taskUuid (POST) */
    private TaskEntity findTask(String idStr, String uuid) {
        com.controlhub.app.data.TaskDao dao = AppDatabase.getInstance(context).taskDao();
        if (uuid != null && !uuid.isEmpty()) return dao.getByUuid(uuid);
        if (idStr != null) {
            try {
                return dao.getById(Long.parseLong(idStr));
            } catch (NumberFormatException ignored) {
            }
        }
        return null;
    }

    // HIGH_RISK. Body: {instructions, priority?, timeoutSeconds?, confirm:true}
    private Response handleTaskCreate(JSONObject body) throws Exception {
        String instructions = body.optString("instructions", "").trim();
        if (instructions.isEmpty()) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'instructions' field"));
        }
        if (instructions.length() > MAX_INSTRUCTIONS_LENGTH) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("'instructions' too long (max " + MAX_INSTRUCTIONS_LENGTH + ")"));
        }
        if (com.controlhub.app.security.EmergencyStopManager.isStopped()) {
            return jsonResponse(Response.Status.CONFLICT, error("Emergency stop is active — resume before creating tasks"));
        }
        // Step 4: adapters expand + mode chunna + validate (galat syntax yahin pakda jata hai)
        InstructionCompiler.Result compiled;
        try {
            compiled = InstructionCompiler.compile(instructions, body.optString("mode", "auto"));
        } catch (IllegalArgumentException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Invalid instructions: " + e.getMessage()));
        }
        // Mode B (foreground/UI) ke liye user ki alag, explicit ijazat chahiye
        if (compiled.needsForeground && !body.optBoolean("allowForeground", false)) {
            JSONObject err = error("This task needs Foreground (UI) mode — it will open apps and tap on screen. "
                    + "Resend with \"allowForeground\": true to confirm.");
            err.put("needsForeground", true);
            return jsonResponse(Response.Status.CONFLICT, err);
        }
        int priority = Math.max(-10, Math.min(10, body.optInt("priority", 0)));
        long timeoutSec = body.optLong("timeoutSeconds", DEFAULT_TIMEOUT_SEC);
        if (timeoutSec <= 0 || timeoutSec > MAX_TIMEOUT_SEC) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("'timeoutSeconds' must be 1.." + MAX_TIMEOUT_SEC));
        }

        long now = System.currentTimeMillis();
        TaskEntity t = new TaskEntity(compiled.instructions, "pending", now, now);
        t.mode = compiled.modeUsed;
        t.restoreApp = body.optBoolean("restoreApp", true);         // task ke baad pichli app par wapas
        t.redactWhenDone = body.optBoolean("redactWhenDone", false); // khatam hote hi message text mita do
        t.priority = priority;
        t.deadlineAt = now + timeoutSec * 1000L;
        t.deviceId = com.controlhub.app.security.DeviceIdentity.get(context);
        t.id = AppDatabase.getInstance(context).taskDao().insert(t);

        AuditLogger.info(context, "Task " + t.id + " created via API (" + AutomationReasoner.parseCommands(compiled.instructions).size()
                + " command(s), mode " + compiled.modeUsed + ", priority " + priority + ")");
        TaskRunner.enqueue(context, t.id, priority);
        return jsonResponse(Response.Status.OK, taskToJson(t));
    }

    private Response handleTaskStatus(IHTTPSession session) throws Exception {
        Map<String, List<String>> params = session.getParameters();
        String idStr = firstParam(params, "id");
        String uuid = firstParam(params, "uuid");
        if (idStr == null && uuid == null) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'id' or 'uuid' query param"));
        }
        TaskEntity t = findTask(idStr, uuid);
        if (t == null) {
            return jsonResponse(Response.Status.NOT_FOUND, error("Task not found"));
        }
        return jsonResponse(Response.Status.OK, taskToJson(t));
    }

    // Optional ?status=pending|running|paused|done|failed|cancelled&limit=1..100
    private Response handleTaskList(IHTTPSession session) throws Exception {
        Map<String, List<String>> params = session.getParameters();
        String status = firstParam(params, "status");
        int limit = 20;
        String limitStr = firstParam(params, "limit");
        if (limitStr != null) {
            try {
                limit = Math.max(1, Math.min(100, Integer.parseInt(limitStr)));
            } catch (NumberFormatException ignored) {
            }
        }
        com.controlhub.app.data.TaskDao dao = AppDatabase.getInstance(context).taskDao();
        List<TaskEntity> rows = (status == null) ? dao.getRecent(limit) : dao.getRecentByStatus(status, limit);
        JSONArray arr = new JSONArray();
        for (TaskEntity t : rows) arr.put(taskToJson(t));
        return jsonResponse(Response.Status.OK, arr);
    }

    private TaskEntity taskFromBody(JSONObject body) {
        String uuid = body.optString("taskUuid", null);
        String idStr = body.has("taskId") ? String.valueOf(body.optLong("taskId", -1)) : null;
        return findTask(idStr, uuid);
    }

    private Response handleTaskCancel(JSONObject body) throws Exception {
        TaskEntity t = taskFromBody(body);
        if (t == null) return jsonResponse(Response.Status.NOT_FOUND, error("Task not found (send taskId or taskUuid)"));
        com.controlhub.app.data.TaskDao dao = AppDatabase.getInstance(context).taskDao();
        if (dao.markCancelled(t.id, System.currentTimeMillis()) == 0) {
            return jsonResponse(Response.Status.CONFLICT, error("Task already " + t.status));
        }
        AuditLogger.warning(context, "Task " + t.id + " cancelled via API");
        dao.redactFinishedFlagged();
        return jsonResponse(Response.Status.OK, taskToJson(dao.getById(t.id)));
    }

    private Response handleTaskPause(JSONObject body) throws Exception {
        TaskEntity t = taskFromBody(body);
        if (t == null) return jsonResponse(Response.Status.NOT_FOUND, error("Task not found (send taskId or taskUuid)"));
        com.controlhub.app.data.TaskDao dao = AppDatabase.getInstance(context).taskDao();
        if (dao.markPaused(t.id, System.currentTimeMillis()) == 0) {
            return jsonResponse(Response.Status.CONFLICT, error("Cannot pause — task is " + t.status));
        }
        AuditLogger.info(context, "Task " + t.id + " paused via API");
        return jsonResponse(Response.Status.OK, taskToJson(dao.getById(t.id)));
    }

    private Response handleTaskResume(JSONObject body) throws Exception {
        TaskEntity t = taskFromBody(body);
        if (t == null) return jsonResponse(Response.Status.NOT_FOUND, error("Task not found (send taskId or taskUuid)"));
        if (com.controlhub.app.security.EmergencyStopManager.isStopped()) {
            return jsonResponse(Response.Status.CONFLICT, error("Emergency stop is active"));
        }
        com.controlhub.app.data.TaskDao dao = AppDatabase.getInstance(context).taskDao();
        if (dao.markResumed(t.id, System.currentTimeMillis()) == 0) {
            return jsonResponse(Response.Status.CONFLICT, error("Cannot resume — task is " + t.status));
        }
        AuditLogger.info(context, "Task " + t.id + " resumed via API");
        TaskRunner.enqueue(context, t.id, t.priority);
        return jsonResponse(Response.Status.OK, taskToJson(dao.getById(t.id)));
    }

    // Step 8: khatam hua task (aur uska message text) hamesha ke liye hatao. Body: {taskId | taskUuid}
    private Response handleTaskDelete(JSONObject body) throws Exception {
        TaskEntity t = taskFromBody(body);
        if (t == null) return jsonResponse(Response.Status.NOT_FOUND, error("Task not found (send taskId or taskUuid)"));
        if (AppDatabase.getInstance(context).taskDao().deleteIfFinished(t.id) == 0) {
            return jsonResponse(Response.Status.CONFLICT, error("Only finished tasks (done/failed/cancelled) can be deleted — task is " + t.status));
        }
        AuditLogger.info(context, "Task " + t.id + " deleted via API");
        JSONObject res = new JSONObject();
        res.put("deleted", true);
        return jsonResponse(Response.Status.OK, res);
    }

    // Step 8 (HIGH_RISK): bahut saare khatam tasks ek saath. Body: {olderThanDays?(default 0 = sab), status?(done|failed|cancelled), confirm:true}
    private Response handleTaskPurge(JSONObject body) throws Exception {
        long days = body.optLong("olderThanDays", 0);
        if (days < 0 || days > 3650) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("'olderThanDays' must be 0..3650"));
        }
        String status = body.has("status") ? body.optString("status", "") : null;
        if (status != null && !(status.equals("done") || status.equals("failed") || status.equals("cancelled"))) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("'status' must be done, failed or cancelled"));
        }
        long cutoff = days == 0 ? System.currentTimeMillis() + 1 : System.currentTimeMillis() - days * 86_400_000L;
        int n = AppDatabase.getInstance(context).taskDao().purgeFinished(cutoff, status);
        AuditLogger.warning(context, "Purged " + n + " finished task(s) via API");
        JSONObject res = new JSONObject();
        res.put("deleted", n);
        return jsonResponse(Response.Status.OK, res);
    }

    // Failed task dobara. Body: {taskId|taskUuid, fromStart?:bool, timeoutSeconds?}
    private Response handleTaskRetry(JSONObject body) throws Exception {
        TaskEntity t = taskFromBody(body);
        if (t == null) return jsonResponse(Response.Status.NOT_FOUND, error("Task not found (send taskId or taskUuid)"));
        if (com.controlhub.app.security.EmergencyStopManager.isStopped()) {
            return jsonResponse(Response.Status.CONFLICT, error("Emergency stop is active"));
        }
        if (TaskEntity.REDACTED.equals(t.instructions)) {
            return jsonResponse(Response.Status.CONFLICT, error("This task's instructions were redacted — create a new task instead"));
        }
        long timeoutSec = body.optLong("timeoutSeconds", DEFAULT_TIMEOUT_SEC);
        if (timeoutSec <= 0 || timeoutSec > MAX_TIMEOUT_SEC) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("'timeoutSeconds' must be 1.." + MAX_TIMEOUT_SEC));
        }
        long now = System.currentTimeMillis();
        long newDeadline = now + timeoutSec * 1000L;
        com.controlhub.app.data.TaskDao dao = AppDatabase.getInstance(context).taskDao();
        int rows = body.optBoolean("fromStart", false)
                ? dao.markRetryFromStart(t.id, now, newDeadline)
                : dao.markRetry(t.id, now, newDeadline);
        if (rows == 0) {
            return jsonResponse(Response.Status.CONFLICT, error("Only failed tasks can be retried — task is " + t.status));
        }
        AuditLogger.info(context, "Task " + t.id + " retried via API");
        TaskRunner.enqueue(context, t.id, t.priority);
        return jsonResponse(Response.Status.OK, taskToJson(dao.getById(t.id)));
    }

    // -------------------- Step 7: long-click, key, device state, file owner + progress --------------------
    private Response handleUiLongClick(JSONObject body) throws Exception {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error("Accessibility Service is not running"));
        }
        if (body.has("element_id")) {
            int elementId = body.getInt("element_id");
            boolean done = TaskQueueManager.getInstance().submitAndWait(() -> service.longTapElement(elementId));
            return jsonResponse(Response.Status.OK, ok("longPressed", done));
        }
        if (body.has("x") && body.has("y")) {
            int x = body.getInt("x");
            int y = body.getInt("y");
            TaskQueueManager.getInstance().submitAndWait(() -> {
                service.longPress(x, y);
                return true;
            });
            return jsonResponse(Response.Status.OK, ok("longPressed", true));
        }
        return jsonResponse(Response.Status.BAD_REQUEST, error("Provide either 'element_id' or 'x'+'y'"));
    }

    private static final java.util.Set<String> API_KEYS = new java.util.HashSet<>(java.util.Arrays.asList(
            "back", "home", "recents", "notifications", "quick_settings", "enter", "clear"));

    private Response handleUiKey(JSONObject body) throws Exception {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE, error("Accessibility Service is not running"));
        }
        final String key = body.optString("key", "").trim().toLowerCase();
        if (!API_KEYS.contains(key)) {
            return jsonResponse(Response.Status.BAD_REQUEST,
                    error("'key' must be one of: back, home, recents, notifications, quick_settings, enter, clear"));
        }
        boolean pressed = TaskQueueManager.getInstance().submitAndWait(() -> service.pressKey(key));
        return jsonResponse(Response.Status.OK, ok("pressed", pressed));
    }

    // READ — doc ka "Device/session: status, health, active task, foreground app, permissions"
    private Response handleDeviceState() throws Exception {
        JSONObject o = new JSONObject();
        DeviceState.Battery b = DeviceState.battery(context);
        JSONObject bat = new JSONObject();
        bat.put("level", b.level);
        bat.put("charging", b.charging);
        bat.put("powerSave", b.powerSave);
        o.put("battery", bat);
        o.put("accessibilityRunning", ControlHubAccessibilityService.isRunning());
        o.put("notificationListenerConnected", ControlHubNotificationListener.isConnected());
        o.put("emergencyStop", EmergencyStopManager.isStopped());
        String blocked = DeviceState.uiBlockedReason(context);
        o.put("uiAvailable", blocked == null);
        o.put("uiBlockedReason", blocked == null ? JSONObject.NULL : blocked);
        o.put("activeTaskId", TaskRunner.currentTaskId());
        ControlHubAccessibilityService svc = ControlHubAccessibilityService.getInstance();
        o.put("foregroundPackage", svc != null && blocked == null ? svc.getForegroundPackage() : "");
        android.os.PowerManager pm = (android.os.PowerManager) context.getSystemService(Context.POWER_SERVICE);
        o.put("batteryOptimizationIgnored", pm != null && pm.isIgnoringBatteryOptimizations(context.getPackageName()));
        return jsonResponse(Response.Status.OK, o);
    }

    private void registerTransfer(JSONObject startResult, JSONObject body) {
        String id = startResult.optString("transferId", "");
        if (id.isEmpty()) return;
        TokenAuth.Principal p = CURRENT_PRINCIPAL.get();
        TRANSFER_OWNER.put(id, p == null ? "master" : p.id);
        String task = body.optString("taskUuid", "");
        if (!task.isEmpty() && task.length() <= 64) TRANSFER_TASK.put(id, task); // optional: transfer kis task ke liye hai
        AuditLogger.info(context, "File transfer " + id + " started (" + startResult.optString("direction", "?")
                + (task.isEmpty() ? "" : ", task " + task) + ")");
    }

    /** null = allowed. Master sab dekh sakta hai; scoped token sirf apni shuru ki hui transfer */
    private Response checkTransferOwner(String transferId) {
        if (transferId == null) return null; // handler khud 400 dega
        TokenAuth.Principal p = CURRENT_PRINCIPAL.get();
        if (p == null || p.master) return null;
        String owner = TRANSFER_OWNER.get(transferId);
        if (owner == null || !owner.equals(p.id)) {
            AuditLogger.warning(context, "Denied file transfer access to " + transferId + " for " + p.label());
            return jsonResponse(Response.Status.FORBIDDEN, error("This transfer belongs to another token"));
        }
        return null;
    }

    /** Progress event (throttled: har 10% par, ya jab state COMPLETED/FAILED/CANCELLED ho) — file content kabhi nahi */
    private void publishFileProgress(String transferId, JSONObject status) {
        try {
            int pct = status.optInt("percent", 0);
            String state = status.optString("state", "");
            boolean terminal = state.equals("COMPLETED") || state.equals("FAILED") || state.equals("CANCELLED");
            Integer last = TRANSFER_LAST_PCT.get(transferId);
            if (!terminal && last != null && pct - last < 10) return;
            TRANSFER_LAST_PCT.put(transferId, pct);
            if (terminal) TRANSFER_LAST_PCT.remove(transferId);
            JSONObject d = new JSONObject();
            d.put("transferId", transferId);
            d.put("direction", status.optString("direction", ""));
            d.put("percent", pct);
            d.put("state", state);
            String task = TRANSFER_TASK.get(transferId);
            if (task != null) d.put("taskUuid", task);
            EventBus.publish("file.progress", d);
        } catch (JSONException ignored) {
        }
    }

    // -------------------- Step 6: scoped tokens (sirf master token, sirf local — relay se nahi) --------------------
    private static String maskToNames(int mask) {
        StringBuilder sb = new StringBuilder();
        if ((mask & ScopedTokenRegistry.READ) != 0) sb.append("READ,");
        if ((mask & ScopedTokenRegistry.WRITE) != 0) sb.append("WRITE,");
        if ((mask & ScopedTokenRegistry.HIGH_RISK) != 0) sb.append("HIGH_RISK,");
        return sb.length() == 0 ? "" : sb.substring(0, sb.length() - 1);
    }

    private JSONObject tokenToJson(ScopedTokenRegistry.Entry e) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", e.id);
        o.put("name", e.name);
        o.put("scopes", maskToNames(e.mask));
        o.put("createdAt", e.createdAt);
        o.put("revoked", e.revoked);
        return o;
    }

    // HIGH_RISK. Body: {name, scopes:["READ","WRITE","HIGH_RISK"], confirm:true, idempotencyKey}
    private Response handleTokenCreate(JSONObject body) throws Exception {
        String name = body.optString("name", "");
        JSONArray arr = body.optJSONArray("scopes");
        if (arr == null || arr.length() == 0) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("'scopes' must be a non-empty array of READ / WRITE / HIGH_RISK"));
        }
        List<String> names = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) names.add(arr.getString(i));
        ScopedTokenRegistry.Created created;
        try {
            created = TokenAuth.registry(context).create(name, TokenAuth.maskFromNames(names));
        } catch (IllegalArgumentException e) {
            return jsonResponse(Response.Status.BAD_REQUEST, error(String.valueOf(e.getMessage())));
        } catch (IllegalStateException e) {
            return jsonResponse(Response.Status.CONFLICT, error(String.valueOf(e.getMessage())));
        }
        AuditLogger.warning(context, "Scoped token created: id=" + created.entry.id + " name=" + created.entry.name
                + " scopes=" + maskToNames(created.entry.mask));
        JSONObject res = tokenToJson(created.entry);
        res.put("token", created.plainToken);
        res.put("note", "Shown only once — store it now. It can be revoked at any time.");
        return jsonResponse(Response.Status.OK, res);
    }

    private Response handleTokenList() throws Exception {
        JSONArray arr = new JSONArray();
        for (ScopedTokenRegistry.Entry e : TokenAuth.registry(context).list()) arr.put(tokenToJson(e));
        return jsonResponse(Response.Status.OK, arr);
    }

    private Response handleTokenRevoke(JSONObject body) throws Exception {
        String id = body.optString("id", "");
        if (id.isEmpty()) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'id'"));
        }
        if (!TokenAuth.registry(context).revoke(id)) {
            return jsonResponse(Response.Status.NOT_FOUND, error("No active token with that id"));
        }
        AuditLogger.warning(context, "Scoped token revoked: id=" + id);
        return jsonResponse(Response.Status.OK, ok("revoked", true));
    }

    // -------------------- Step 5: remote Emergency Stop --------------------
    // Fail-safe: READ scope wale sabse restricted token se bhi chalta hai (rokna hamesha allowed).
    // RESUME remote se nahi — sirf phone par user khud karta hai (koi attacker/galat agent dobara chalu na kare).
    private Response handleEmergencyStop() throws Exception {
        com.controlhub.app.security.EmergencyStopManager.trigger(context); // audit trigger() ke andar hota hai
        JSONObject res = new JSONObject();
        res.put("stopped", true);
        res.put("note", "All active tasks cancelled. Resume is only possible on the phone itself.");
        return jsonResponse(Response.Status.OK, res);
    }

    // -------------------- Step 4: notifications + adapters --------------------
    // READ. Title/text tabhi dikhte hain jab user Settings mein "Expose notification text" ON kare.
    private Response handleNotifications(IHTTPSession session) throws Exception {
        Map<String, List<String>> params = session.getParameters();
        String pkg = firstParam(params, "package");
        int limit = 20;
        String limitStr = firstParam(params, "limit");
        if (limitStr != null) {
            try {
                limit = Math.max(1, Math.min(100, Integer.parseInt(limitStr)));
            } catch (NumberFormatException ignored) {
            }
        }
        boolean exposeText = NotificationStore.isTextExposed(context);
        JSONObject res = new JSONObject();
        res.put("listenerConnected", ControlHubNotificationListener.isConnected());
        res.put("textExposed", exposeText);
        JSONArray arr = new JSONArray();
        for (NotificationStore.Item it : NotificationStore.list(pkg, limit)) {
            JSONObject o = new JSONObject();
            o.put("key", it.key);
            o.put("package", it.pkg);
            o.put("postTime", it.postTime);
            o.put("hasReply", it.hasReply);
            o.put("ongoing", it.ongoing);
            o.put("groupSummary", it.groupSummary);
            o.put("category", it.category == null ? JSONObject.NULL : it.category);
            if (exposeText) {
                o.put("title", it.title);
                o.put("text", it.text);
            }
            arr.put(o);
        }
        res.put("notifications", arr);
        return jsonResponse(Response.Status.OK, res);
    }

    // HIGH_RISK. Body: {key, text, confirm:true} — Mode A (background) inline reply
    private Response handleNotificationReply(JSONObject body) throws Exception {
        String key = body.optString("key", "");
        String text = body.optString("text", "");
        if (key.isEmpty() || text.isEmpty()) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("Missing 'key' or 'text'"));
        }
        if (text.length() > 2000) {
            return jsonResponse(Response.Status.BAD_REQUEST, error("'text' too long (max 2000)"));
        }
        if (!ControlHubNotificationListener.isConnected()) {
            return jsonResponse(Response.Status.SERVICE_UNAVAILABLE,
                    error("Notification access is not enabled — turn it on in Control Hub Settings"));
        }
        NotificationStore.Item item = NotificationStore.get(key);
        if (item == null || !item.hasReply) {
            return jsonResponse(Response.Status.NOT_FOUND, error("No reply-able notification with that key (expired?)"));
        }
        String err = ControlHubNotificationListener.sendReply(context, item, text);
        if (err != null) {
            return rawJson(502, error(err).toString(), null, null);
        }
        AuditLogger.info(context, "Inline reply sent via API (pkg=" + item.pkg + ", len=" + text.length() + ")");
        JSONObject res = new JSONObject();
        res.put("sent", true);
        res.put("deliveryConfirmed", false); // honest: sirf system ne intent le liya
        return jsonResponse(Response.Status.OK, res);
    }

    private Response handleAdapters() throws Exception {
        JSONArray arr = new JSONArray();
        for (AppAdapter a : AdapterRegistry.all()) {
            JSONObject o = new JSONObject();
            o.put("name", a.name());
            o.put("package", a.packageName());
            o.put("version", a.version());
            o.put("status", a.status());
            o.put("description", a.description());
            JSONArray acts = new JSONArray();
            for (String act : a.actions()) {
                JSONObject ao = new JSONObject();
                ao.put("action", act);
                ao.put("supportsBackground", a.supportsBackground(act));
                acts.put(ao);
            }
            o.put("actions", acts);
            arr.put(o);
        }
        return jsonResponse(Response.Status.OK, arr);
    }

    // -------------------- Helpers --------------------
    private JSONObject readJsonBody(IHTTPSession session) throws Exception {
        Map<String, String> files = new HashMap<>();
        session.parseBody(files);
        String raw = files.get("postData");
        if (raw == null) raw = "{}";
        return new JSONObject(raw);
    }

    private String firstParam(Map<String, List<String>> params, String key) {
        List<String> values = params.get(key);
        return (values != null && !values.isEmpty()) ? values.get(0) : null;
    }

    /** Step 5: FilePolicy.Rejected -> sahi HTTP code (413 size, 415 type, 422 checksum, 429, 507) */
    private Response rejectedResponse(FilePolicy.Rejected r) {
        final int code = r.status;
        final String desc = code + " " + (code == 413 ? "Payload Too Large"
                : code == 415 ? "Unsupported Media Type"
                : code == 422 ? "Unprocessable Entity"
                : code == 429 ? "Too Many Requests"
                : code == 507 ? "Insufficient Storage" : "Rejected");
        Response.IStatus status = new Response.IStatus() {
            @Override
            public String getDescription() {
                return desc;
            }

            @Override
            public int getRequestStatus() {
                return code;
            }
        };
        return newFixedLengthResponse(status, "application/json", error(String.valueOf(r.getMessage())).toString());
    }

    /** Kisi bhi HTTP code ke saath JSON jawab (+ optional ek header) */
    private Response rawJson(int code, String body, String headerName, String headerValue) {
        final int c = code;
        final String desc = c + " " + (c == 428 ? "Precondition Required" : c == 429 ? "Too Many Requests" : c == 422 ? "Unprocessable Entity" : c == 502 ? "Bad Gateway"
                : c == 200 ? "OK" : c == 201 ? "Created" : c == 202 ? "Accepted" : "Status");
        Response.IStatus st = new Response.IStatus() {
            @Override
            public String getDescription() {
                return desc;
            }

            @Override
            public int getRequestStatus() {
                return c;
            }
        };
        Response r = newFixedLengthResponse(st, "application/json", body == null ? "" : body);
        if (headerName != null) r.addHeader(headerName, headerValue);
        return r;
    }

    private Response jsonResponse(Response.Status status, Object json) {
        IdemCtx ctx = IDEM_CTX.get(); // Step 6: idempotent request ka jawab replay ke liye yaad rakho
        if (ctx != null) {
            ctx.status = status.getRequestStatus();
            ctx.body = json.toString();
        }
        return newFixedLengthResponse(status, "application/json", json.toString());
    }

    private JSONObject ok(String key, Object value) {
        JSONObject obj = new JSONObject();
        try {
            obj.put(key, value);
        } catch (JSONException ignored) {
        }
        return obj;
    }

    private JSONObject error(String message) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("error", message);
        } catch (JSONException ignored) {
        }
        return obj;
    }
}
