package com.controlhub.app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.controlhub.app.api.ApiTokenManager;
import com.controlhub.app.connectors.WebhookConfig;
import com.controlhub.app.connectors.WebhookConnector;
import com.controlhub.app.relay.RelayClient;
import com.controlhub.app.relay.RelayConfig;
import com.controlhub.app.security.ApiScope;
import com.controlhub.app.security.AuditLogger;
import com.controlhub.app.security.ScopeManager;
import com.controlhub.app.service.ControlHubForegroundService;

/**
 * Feature #4  — Settings screen
 * Feature #20 — API token dikhana + regenerate
 * Feature #39 — Scope ON/OFF switches (Stage 8 mein ye UI missing tha)
 * Feature #55 — Remote relay ka URL + device token, aur live connection status
 * Feature #58 — Webhook connector ka URL, event filter, test button
 */
public class SettingsActivity extends AppCompatActivity {

    private TextView notifStatusText;
    private TextView batteryStatusText;
    private TextView relayStatusText;
    private TextView webhookStatusText;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusPoller = new Runnable() {
        @Override
        public void run() {
            updateRelayStatus();
            updateWebhookStatus();
            updateNotifStatus();
            updateBatteryStatus();
            handler.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // ---- API token (Feature #20) ----
        TextView tokenText = findViewById(R.id.apiTokenText);
        Button regenerateButton = findViewById(R.id.regenerateTokenButton);
        tokenText.setText(ApiTokenManager.getOrCreateToken(this));
        regenerateButton.setOnClickListener(v ->
                tokenText.setText(ApiTokenManager.regenerateToken(this)));

        // ---- Scope switches (Feature #39) ----
        bindScopeSwitch(R.id.scopeReadSwitch, ApiScope.READ);
        bindScopeSwitch(R.id.scopeWriteSwitch, ApiScope.WRITE);
        bindScopeSwitch(R.id.scopeHighRiskSwitch, ApiScope.HIGH_RISK);

        // ---- Step 8: LAN access + task auto-delete ----
        SwitchCompat lanSwitch = findViewById(R.id.lanSwitch);
        lanSwitch.setChecked(com.controlhub.app.api.NetworkBinding.isLanAllowed(this));
        lanSwitch.setOnCheckedChangeListener((v, isChecked) -> {
            com.controlhub.app.api.NetworkBinding.setLanAllowed(this, isChecked);
            AuditLogger.warning(this, "LAN access turned " + (isChecked ? "ON" : "OFF"));
            com.controlhub.app.service.ControlHubForegroundService.restartServers(this);
            Toast.makeText(this, isChecked ? "LAN access ON — only use on trusted WiFi"
                    : "Local API is now phone-only", Toast.LENGTH_LONG).show();
        });
        SwitchCompat autoDeleteSwitch = findViewById(R.id.autoDeleteSwitch);
        autoDeleteSwitch.setChecked(com.controlhub.app.automation.TaskRetention.isAutoDeleteEnabled(this));
        autoDeleteSwitch.setOnCheckedChangeListener((v, isChecked) -> {
            com.controlhub.app.automation.TaskRetention.setAutoDeleteEnabled(this, isChecked);
            AuditLogger.warning(this, "Task auto-delete turned " + (isChecked ? "ON" : "OFF"));
        });

        // ---- Step 6: battery optimization (Doze) se chhoot ----
        batteryStatusText = findViewById(R.id.batteryStatusText);
        Button batteryButton = findViewById(R.id.batteryButton);
        batteryButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        android.net.Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                try {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                } catch (ActivityNotFoundException e2) {
                    Toast.makeText(this, "Battery settings not available on this device", Toast.LENGTH_LONG).show();
                }
            }
        });

        // ---- Step 4: notification access + privacy switch ----
        notifStatusText = findViewById(R.id.notifStatusText);
        Button notifAccessButton = findViewById(R.id.notifAccessButton);
        notifAccessButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Notification access settings not available on this device", Toast.LENGTH_LONG).show();
            }
        });
        SwitchCompat notifTextSwitch = findViewById(R.id.notifTextSwitch);
        notifTextSwitch.setChecked(com.controlhub.app.notifications.NotificationStore.isTextExposed(this));
        notifTextSwitch.setOnCheckedChangeListener((v, isChecked) -> {
            com.controlhub.app.notifications.NotificationStore.setTextExposed(this, isChecked);
            AuditLogger.warning(this, "Notification text exposure turned " + (isChecked ? "ON" : "OFF"));
        });

        // ---- Step 2: start on boot ----
        SwitchCompat bootSwitch = findViewById(R.id.bootStartSwitch);
        bootSwitch.setChecked(com.controlhub.app.service.BootReceiver.isEnabled(this));
        bootSwitch.setOnCheckedChangeListener((v, isChecked) -> {
            com.controlhub.app.service.BootReceiver.setEnabled(this, isChecked);
            AuditLogger.warning(this, "Start-on-boot turned " + (isChecked ? "ON" : "OFF"));
        });

        // ---- Relay (Feature #55) ----
        EditText urlInput = findViewById(R.id.relayUrlInput);
        EditText tokenInput = findViewById(R.id.relayTokenInput);
        relayStatusText = findViewById(R.id.relayStatusText);
        urlInput.setText(RelayConfig.getUrl(this));
        tokenInput.setText(RelayConfig.getDeviceToken(this));

        findViewById(R.id.saveRelayButton).setOnClickListener(v -> {
            String error = RelayConfig.save(this,
                    urlInput.getText().toString(), tokenInput.getText().toString());
            if (error != null) {
                relayStatusText.setText("Not saved: " + error);
                return;
            }
            AuditLogger.info(this, "Relay settings changed");
            // Service chal rahi ho to naye config ke saath turant dobara connect
            if (ControlHubForegroundService.isRunning()) {
                RelayClient.restart(this);
            }
            urlInput.setText(RelayConfig.getUrl(this)); // normalized URL dikhao
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            updateRelayStatus();
        });

        // ---- Webhook connector (Feature #58) ----
        EditText webhookUrlInput = findViewById(R.id.webhookUrlInput);
        SwitchCompat webhookAllSwitch = findViewById(R.id.webhookAllSwitch);
        webhookStatusText = findViewById(R.id.webhookStatusText);
        webhookUrlInput.setText(WebhookConfig.getUrl(this));
        webhookAllSwitch.setChecked(WebhookConfig.isForwardAll(this));

        findViewById(R.id.saveWebhookButton).setOnClickListener(v -> {
            String error = WebhookConfig.save(this,
                    webhookUrlInput.getText().toString(), webhookAllSwitch.isChecked());
            if (error != null) {
                webhookStatusText.setText("Not saved: " + error);
                return;
            }
            AuditLogger.info(this, "Webhook settings changed");
            if (ControlHubForegroundService.isRunning()) {
                WebhookConnector.restart(this);
            }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            updateWebhookStatus();
        });

        findViewById(R.id.testWebhookButton).setOnClickListener(v -> {
            if (!WebhookConfig.isConfigured(this)) {
                webhookStatusText.setText("Pehle ek URL save karo");
                return;
            }
            WebhookConnector.sendTest(this);
            updateWebhookStatus();
        });

        // ---- Battery ----
        findViewById(R.id.batterySettingsButton).setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Open phone Settings > Battery manually", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(statusPoller);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusPoller);
    }

    private void bindScopeSwitch(int viewId, ApiScope scope) {
        SwitchCompat toggle = findViewById(viewId);
        toggle.setChecked(ScopeManager.isEnabled(this, scope));
        toggle.setOnCheckedChangeListener((button, isChecked) -> {
            ScopeManager.setEnabled(this, scope, isChecked);
            AuditLogger.warning(this, "Scope " + scope + " turned " + (isChecked ? "ON" : "OFF"));
        });
    }

    private void updateWebhookStatus() {
        if (!WebhookConfig.isConfigured(this)) {
            webhookStatusText.setText("Webhook: not configured");
            return;
        }
        String state = ControlHubForegroundService.isRunning()
                ? "active" : "saved (server start hone par chalega)";
        webhookStatusText.setText("Webhook: " + state + "\nLast delivery: " + WebhookConnector.getLastResult());
    }

    private void updateBatteryStatus() {
        if (batteryStatusText == null) return;
        android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
        boolean unrestricted = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        batteryStatusText.setText(unrestricted
                ? "Battery optimization: OFF for Control Hub (good for 24/7)"
                : "Battery optimization: ON — Android may pause Control Hub in Doze. Tap the button to allow.");
    }

    private void updateNotifStatus() {
        if (notifStatusText == null) return;
        boolean on = com.controlhub.app.notifications.ControlHubNotificationListener.isConnected();
        notifStatusText.setText(on ? "Notification access: ON (inline reply possible)"
                : "Notification access: OFF (needed for background reply)");
    }

    private void updateRelayStatus() {
        if (!RelayConfig.isConfigured(this)) {
            relayStatusText.setText("Relay: not configured");
            return;
        }
        if (!ControlHubForegroundService.isRunning()) {
            relayStatusText.setText("Relay: configured — Dashboard par 'Start API Server' dabao");
            return;
        }
        RelayClient.State state = RelayClient.getState();
        String text = "Relay: " + state;
        if (state == RelayClient.State.WAITING_RETRY && !RelayClient.getLastError().isEmpty()) {
            text += " (" + RelayClient.getLastError() + ")";
        }
        relayStatusText.setText(text);
    }
}
