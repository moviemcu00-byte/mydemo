package com.controlhub.app.security;

/**
 * Feature #39 — Scope system
 *
 * Har endpoint ek scope ke andar aata hai. Token ke paas valid hona kaafi
 * nahi — us scope ka access bhi ON hona chahiye (Settings mein user khud
 * kisi scope ko band kar sakta hai, jaise "abhi ke liye WRITE actions band
 * kar do, sirf READ chalne do").
 */
public enum ApiScope {
    READ,        // /apps, /app/status, /ui/read, /screenshot, /capabilities, /health
    WRITE,       // /app/launch, /ui/click, /ui/scroll
    HIGH_RISK;   // /app/stop, /ui/type — Feature #40 ka extra confirmation bhi maangega

    /** Feature #39 — kaunsa endpoint kis scope mein aata hai */
    public static ApiScope forEndpoint(String uri) {
        switch (uri) {
            case "/health":
            case "/apps":
            case "/app/status":
            case "/ui/read":
            case "/screenshot":
            case "/capabilities":
            case "/scene":
            case "/device/state":
            case "/auth/tokens/list":
            case "/emergency/stop":
            case "/emergency/status":
            case "/notifications":
            case "/adapters":
            case "/task/status":
            case "/task/list":
                return READ;

            case "/app/launch":
            case "/ui/long_click":
            case "/ui/key":
            case "/ui/click":
            case "/ui/scroll":
            case "/ui/back":
            case "/ui/home":
            case "/auth/tokens/revoke":
            case "/task/delete":
            case "/task/cancel":
            case "/task/pause":
            case "/task/resume":
            case "/task/retry":
                return WRITE;

            case "/file/send/start":
            case "/file/send/status":
            case "/file/send/chunk":
            case "/file/send/pause":
            case "/file/send/resume":
            case "/file/send/cancel":
                return READ; // phone se bahar sirf padhna hai, kuch likhna/badalna nahi

            case "/file/receive/start":
            case "/file/receive/chunk":
            case "/file/receive/status":
            case "/file/receive/pause":
            case "/file/receive/resume":
            case "/file/receive/cancel":
                return WRITE; // phone par naya file data likha jaata hai

            case "/app/stop":
            case "/ui/type":
            case "/auth/tokens/create":
            case "/task/purge":
            case "/task/create":
            case "/notification/reply":
                return HIGH_RISK;

            default:
                return HIGH_RISK; // unknown endpoint — safest default hi HIGH_RISK rakho
        }
    }
}
