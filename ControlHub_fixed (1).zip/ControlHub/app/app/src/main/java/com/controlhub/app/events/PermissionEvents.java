package com.controlhub.app.events;

import org.json.JSONException;
import org.json.JSONObject;

/** Step 7 — "permission.changed" event: accessibility / notification-access ON ya OFF hua */
public class PermissionEvents {

    public static void publish(String permission, boolean enabled) {
        try {
            JSONObject d = new JSONObject();
            d.put("permission", permission);
            d.put("enabled", enabled);
            EventBus.publish("permission.changed", d);
        } catch (JSONException ignored) {
        }
    }
}
