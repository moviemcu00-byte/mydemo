package com.controlhub.app.automation;

/**
 * Step 8 — "Open-app rollback" ka faisla (PURE JAVA, test-able).
 * Task khatam hone par phone ko wapas wahin le jao jahan user pehle tha — par sirf tab jab ye safe ho.
 */
public class RollbackPolicy {

    public enum Action { NONE, GO_HOME, LAUNCH_START_APP }

    /**
     * @param mode          task ka mode ("foreground" hi UI chalata hai)
     * @param restoreApp    task ka restoreApp flag
     * @param startPackage  task shuru hone se pehle foreground app ("" = pata nahi)
     * @param currentPackage abhi foreground app
     * @param launcherPackage phone ka home-screen (launcher) package
     * @param ownPackage    Control Hub ka apna package (apne aap par wapas nahi jaate)
     * @param emergencyStopped Emergency Stop ON ho to kabhi UI nahi chalate
     * @param uiBlocked     screen off/locked
     */
    public static Action decide(String mode, boolean restoreApp, String startPackage, String currentPackage,
                                String launcherPackage, String ownPackage, boolean emergencyStopped, boolean uiBlocked) {
        if (emergencyStopped || uiBlocked) return Action.NONE;
        if (!"foreground".equals(mode) || !restoreApp) return Action.NONE;
        if (startPackage == null || startPackage.isEmpty()) return Action.NONE;
        if (startPackage.equals(currentPackage)) return Action.NONE;          // pehle hi wahin hain
        if (startPackage.equals(ownPackage)) return Action.NONE;
        if (startPackage.equals(launcherPackage)) return Action.GO_HOME;      // user home screen par tha
        return Action.LAUNCH_START_APP;
    }
}
