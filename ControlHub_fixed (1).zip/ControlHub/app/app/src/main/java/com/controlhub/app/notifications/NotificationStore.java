package com.controlhub.app.notifications;

import android.app.Notification;
import android.content.Context;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

/**
 * Step 4 — Aaj ke active notifications ka IN-MEMORY store (DB mein kabhi nahi, audit log mein kabhi nahi).
 *
 * Privacy:
 *  - Notification ka title/text API se tabhi dikhta hai jab user Settings mein
 *    "Expose notification text via API" khud ON kare (default OFF).
 *  - Listener disconnect hone par store khaali ho jaata hai.
 */
public class NotificationStore {

    public static class Item {
        public String key;
        public String pkg;
        public String title = "";
        public String text = "";
        public String category;
        public long postTime;
        public boolean hasReply;
        public boolean ongoing;
        public boolean groupSummary;
        public Notification.Action replyAction; // sirf memory mein (PendingIntent)
    }

    private static final int MAX_ITEMS = 80;
    private static final LinkedHashMap<String, Item> ITEMS = new LinkedHashMap<>();

    public static synchronized void put(Item item) {
        ITEMS.remove(item.key);
        ITEMS.put(item.key, item);
        while (ITEMS.size() > MAX_ITEMS) {
            String oldest = ITEMS.keySet().iterator().next();
            ITEMS.remove(oldest);
        }
    }

    public static synchronized void remove(String key) {
        ITEMS.remove(key);
    }

    public static synchronized void clear() {
        ITEMS.clear();
    }

    public static synchronized Item get(String key) {
        return key == null ? null : ITEMS.get(key);
    }

    /** Newest pehle. pkg null/"*" = sab apps. */
    public static synchronized List<Item> list(String pkg, int limit) {
        List<Item> all = new ArrayList<>(ITEMS.values());
        List<Item> out = new ArrayList<>();
        for (int i = all.size() - 1; i >= 0 && out.size() < limit; i--) {
            Item it = all.get(i);
            if (pkg == null || pkg.equals("*") || pkg.equals(it.pkg)) out.add(it);
        }
        return out;
    }

    /**
     * Reply-able notification dhoondo: key barabar ho, ya title mein target ho (case-insensitive).
     * Group-summary notifications skip. Newest pehle.
     */
    public static synchronized Item findReplyable(String pkg, String keyOrContact) {
        if (keyOrContact == null || keyOrContact.isEmpty()) return null;
        String needle = keyOrContact.toLowerCase(Locale.ROOT);
        List<Item> all = new ArrayList<>(ITEMS.values());
        for (int i = all.size() - 1; i >= 0; i--) {
            Item it = all.get(i);
            if (!it.hasReply || it.groupSummary) continue;
            if (pkg != null && !pkg.equals("*") && !pkg.equals(it.pkg)) continue;
            if (keyOrContact.equals(it.key)) return it;
            if (it.title != null && it.title.toLowerCase(Locale.ROOT).contains(needle)) return it;
        }
        return null;
    }

    // ---- privacy setting ----
    private static final String PREFS = "control_hub_notif_prefs";
    private static final String KEY_EXPOSE = "expose_text";

    public static boolean isTextExposed(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_EXPOSE, false);
    }

    public static void setTextExposed(Context c, boolean on) {
        c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_EXPOSE, on).apply();
    }
}
