package android.graphics;
public class Rect { public int left,top,right,bottom;
 public Rect(){} public Rect(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;} public Rect(Rect o){left=o.left;top=o.top;right=o.right;bottom=o.bottom;}
 public int centerX(){return (left+right)/2;} public int centerY(){return (top+bottom)/2;} public boolean isEmpty(){return left>=right||top>=bottom;}
 public String toShortString(){return "["+left+","+top+"]["+right+","+bottom+"]";}
 public boolean equals(Object o){ if(!(o instanceof Rect)) return false; Rect r=(Rect)o; return left==r.left&&top==r.top&&right==r.right&&bottom==r.bottom; }
 public int hashCode(){return left*31+top;} }
